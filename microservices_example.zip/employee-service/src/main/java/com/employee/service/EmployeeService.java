package com.employee.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.employee.model.Employee;

@Service
@SuppressWarnings("all")
public class EmployeeService {

	private static String SERVER_PATH = "http://0.0.0.0:3300/db/employee";
	private static String ADD_URL = SERVER_PATH + "/add";
	private static String UPDATE_URL = SERVER_PATH + "/update";
	private static String REMOVE_URL = SERVER_PATH + "/remove?empid=";
	private static String SEARCH_URL = SERVER_PATH + "/search?empid=";
	private static String GET_ALL = SERVER_PATH + "/getall";

	@Autowired
	private RestTemplate restTemplate;

	public Employee addEmployee(Employee employee) {
		HttpEntity<Employee> entity = new HttpEntity<Employee>(employee, getHeaders());
		return restTemplate.exchange(ADD_URL, HttpMethod.POST, entity, Employee.class).getBody();
	}
	
	public Employee updateEmployee(Employee employee) {
		HttpEntity<Employee> entity = new HttpEntity<Employee>(employee, getHeaders());
		return restTemplate.exchange(UPDATE_URL, HttpMethod.POST, entity, Employee.class).getBody();
	}

	public boolean removeEmployee(String empid) {
		HttpEntity<Employee> entity = new HttpEntity<Employee>(getHeaders());
		return restTemplate.exchange(REMOVE_URL, HttpMethod.GET, entity, Boolean.class).getBody();
	}


	public Employee searchEmployee(String empid) {
		HttpEntity<Employee> entity = new HttpEntity<Employee>(getHeaders());
		return restTemplate.exchange(SEARCH_URL, HttpMethod.GET, entity, Employee.class).getBody();
	}

	public List<Employee> getAllEmployee() {
		HttpEntity<Employee> entity = new HttpEntity<Employee>(getHeaders());
		return (List<Employee>) restTemplate.exchange(GET_ALL, HttpMethod.GET, entity, Object.class).getBody();

	}

	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		return headers;
	}
}
