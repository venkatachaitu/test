#!/bin/sh

# Delete all containers
docker rm $(docker ps -a -q)
# Delete all images
docker rmi $(docker images -q)

find ./ -type d -exec chmod 777 {} \;


cd discovery-service
echo "*************************** [ web ] STARTED CREATING DOCKER*********************************" 
docker build -t discovery-service .
echo "*************************** [ web ] CREATD DOCKER*********************************" 
cd ..

cd employee-service; 
mvn clean;
mvn package;
echo "*************************** [ discovery-service ] STARTED CREATING DOCKER*********************************" 
mvn docker:build
echo "*************************** [ discovery-service ] CREATD DOCKER*********************************" 
cd ..


cd student-service; 
mvn clean;
mvn package;
echo "*************************** [ template-engine-service ] STARTED CREATING DOCKER*********************************" 
mvn docker:build
echo "*************************** [ template-engine-service ] CREATD DOCKER*********************************" 
cd ..


echo "*************************** [ CREATED ALL DOCKER IMAGES ]*********************************" 

docker container ps -a;

docker images;


echo "*************************** [ STARTING DOCKER COMPOSE.. ]*********************************" 
docker-compose up