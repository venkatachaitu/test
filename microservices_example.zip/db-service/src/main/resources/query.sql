DROP TABLE IF EXISTS Student;
CREATE TABLE Student (id INT(255) not null, branch varchar(255), college varchar(255), dob date, name varchar(255), PRIMARY KEY (id));




DROP TABLE IF EXISTS Employee;
CREATE TABLE Employee (id INT(255) not null, designation varchar(255), company varchar(255), dob date, name varchar(255), PRIMARY KEY (id));