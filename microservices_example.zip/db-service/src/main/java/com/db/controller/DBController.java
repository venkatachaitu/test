package com.db.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.db.dao.DbServiceDaoImpl;
import com.db.model.Employee;
import com.db.model.Student;

@Validated
@RestController
@RequestMapping("/db")
public class DBController {
	
	@Autowired
	DbServiceDaoImpl dbServiceDaoImpl;

	//---------STUDENT API'S-------------
    
    @PostMapping("/student/add")
    public Student addStudent(@RequestBody Student student) {
       return dbServiceDaoImpl.addStudent(student);
    }

    @GetMapping("/student/remove")
    public boolean removeStudent(@RequestParam String rollno) {
        return dbServiceDaoImpl.removeStudent(rollno);
    }

    @PostMapping("/student/update")
    public Student updateStudent(@RequestBody Student student) {
        return dbServiceDaoImpl.updateStudent(student);
    }

    @GetMapping("/student/search")
    public Student searchStudent(@RequestParam String rollno) {
        return dbServiceDaoImpl.searchStudent(rollno);
    }
    
    @GetMapping("/student/getall")
    public List<Student> getAllStudent() {
        return dbServiceDaoImpl.getAllStudent();
    }
    
    
    //--------------EMPLOYEE API'S---------
    
    @PostMapping("/employee/add")
    public Employee addEmployee(@RequestBody Employee employee) {
       return dbServiceDaoImpl.addEmployee(employee);
    }

    @GetMapping("/employee/remove")
    public boolean removeEmployee(@RequestParam String empid) {
        return dbServiceDaoImpl.removeEmployee(empid);
    }

    @PostMapping("/employee/update")
    public Employee updateEmployee(@RequestBody Employee employee) {
        return dbServiceDaoImpl.updateEmployee(employee);
    }

    @GetMapping("/employee/search")
    public Employee searchEmployee(@RequestParam String empid) {
        return dbServiceDaoImpl.searchEmployee(empid);
    }
    
    @GetMapping("/employee/getall")
    public List<Employee> getAllEmployee() {
        return dbServiceDaoImpl.getAllEmployee();
    }
    
    
}
