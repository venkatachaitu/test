package com.db.dao;

import com.db.model.Employee;
import com.db.model.Student;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface DbServiceDao {

	Student addStudent(Student student);

    boolean removeStudent(String rollno);

    Student updateStudent(Student student);

	Student searchStudent(String rollno);

	List<Student> getAllStudent();
	
	
	
	Employee addEmployee(Employee employee);

    boolean removeEmployee(String id);

    Employee updateEmployee(Employee employee);

	Employee searchEmployee(String id);

	List<Employee> getAllEmployee();
}
