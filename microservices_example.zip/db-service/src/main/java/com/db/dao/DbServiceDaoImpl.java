package com.db.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.db.model.Student;
import com.db.model.Employee;;

@Repository
@Transactional
public class DbServiceDaoImpl implements DbServiceDao {

    @Autowired
    SessionFactory sessionFactory;

    //-------------------STUDENT--------------------------------
    
    public Student addStudent(Student students) {
    	sessionFactory.getCurrentSession().save(students);
        return students;
    }
    
    public Student updateStudent(Student student) {
    	sessionFactory.getCurrentSession().saveOrUpdate(student);
		return student;
    }

    public boolean removeStudent(String rollno) {
    	Student student = new Student();
    	student.setId(Integer.parseInt(rollno));
    	sessionFactory.getCurrentSession().delete(student);
        return true;
    }

    public Student searchStudent(String rollno) {
    	return (Student) sessionFactory.getCurrentSession().get(Student.class, Integer.parseInt(rollno));
    }
    
    @SuppressWarnings("all")
	public List<Student> getAllStudent() {
		return sessionFactory.getCurrentSession().createCriteria(Student.class).list();
	}
    
    
    //--------------------EMPLOYEE------------------------------
    
    
    public Employee addEmployee(Employee employee) {
    	sessionFactory.getCurrentSession().save(employee);
        return employee;
    }
    
    public Employee updateEmployee(Employee employee) {
    	sessionFactory.getCurrentSession().saveOrUpdate(employee);
		return employee;
    }

    public boolean removeEmployee(String rollno) {
    	Employee employee = new Employee();
    	employee.setId(Integer.parseInt(rollno));
    	sessionFactory.getCurrentSession().delete(employee);
        return true;
    }

    public Employee searchEmployee(String rollno) {
    	return (Employee) sessionFactory.getCurrentSession().get(Employee.class, Integer.parseInt(rollno));
    }
    
    @SuppressWarnings("all")
	public List<Employee> getAllEmployee() {
		return sessionFactory.getCurrentSession().createCriteria(Employee.class).list();
	}
    
    
   
    //-------------------session factory---------------------

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

}
