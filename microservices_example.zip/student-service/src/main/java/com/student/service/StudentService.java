package com.student.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.student.model.Student;

@Service
@SuppressWarnings("all")
public class StudentService {

	private static String SERVER_PATH = "http://127.0.0.1:3300/db/student";
	private static String ADD_URL = SERVER_PATH + "/add";
	private static String UPDATE_URL = SERVER_PATH + "/update";
	private static String REMOVE_URL = SERVER_PATH + "/remove?rollno=";
	private static String SEARCH_URL = SERVER_PATH + "/search?rollno=";
	private static String GET_ALL = SERVER_PATH + "/getall";

	@Autowired
	private RestTemplate restTemplate;

	public Student addStudent(Student student) {
		HttpEntity<Student> entity = new HttpEntity<Student>(student, getHeaders());
		return restTemplate.exchange(ADD_URL, HttpMethod.POST, entity, Student.class).getBody();
	}
	
	public Student updateStudent(Student student) {
		HttpEntity<Student> entity = new HttpEntity<Student>(student, getHeaders());
		return restTemplate.exchange(UPDATE_URL, HttpMethod.POST, entity, Student.class).getBody();
	}

	public boolean removeStudent(String rollno) {
		HttpEntity<Student> entity = new HttpEntity<Student>(getHeaders());
		return restTemplate.exchange(REMOVE_URL, HttpMethod.GET, entity, Boolean.class).getBody();
	}

	public Student searchStudent(String rollno) {
		HttpEntity<Student> entity = new HttpEntity<Student>(getHeaders());
		return restTemplate.exchange(SEARCH_URL, HttpMethod.GET, entity, Student.class).getBody();
	}

	public List<Student> getAllStudent() {
		HttpEntity<Student> entity = new HttpEntity<Student>(getHeaders());
		return (List<Student>) restTemplate.exchange(GET_ALL, HttpMethod.GET, entity, Object.class).getBody();
	}

	private HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		return headers;
	}

}
