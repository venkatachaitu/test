package com.student.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.student.model.Student;
import com.student.service.StudentService;

@Validated
@RestController
@RequestMapping("/student")
public class StudentController {

    @Autowired
    public StudentService studentService;
    
    @Autowired
    RestTemplate restTemplate;

    @PostMapping("/add")
    public Student addStudent(@RequestBody Student student) {
       return studentService.addStudent(student);
    }

    @GetMapping("/remove")
    public boolean removeStudent(@RequestParam String rollno) {
        return studentService.removeStudent(rollno);
    }

    @PostMapping("/update")
    public Student updateStudent(@RequestBody Student student) {
        return studentService.updateStudent(student);
    }

    @GetMapping("/search")
    public Student searchStudent(@RequestParam String rollno) {
        return studentService.searchStudent(rollno);
    }
    
    @GetMapping("/getall")
    public List<Student> getAllStudent() {
        return studentService.getAllStudent();
    }
    
}
