/**
 *  Provides functionality for drawing nodes and edges as well as
 *  drawing proper relationships between the node/edge entities.
 *
 *  Copyright (c) 2015-2017 by Cisco Systems, Inc.
 *
 *  ALL RIGHTS RESERVED. THESE SOURCE FILES ARE THE SOLE PROPERTY
 *  OF CISCO SYSTEMS, Inc. AND CONTAIN CONFIDENTIAL  AND PROPRIETARY
 *  INFORMATION.  REPRODUCTION OR DUPLICATION BY ANY MEANS OF ANY
 *  PORTION OF THIS SOFTWARE WITHOUT PRIOR WRITTEN CONSENT OF
 *  CISCO SYSTEMS, Inc. IS STRICTLY PROHIBITED.
 *
 *  @author Uffaz Nathaniel    mailto:unathani@cisco.com
 *  @author Jason Notari       mailto:jnotari@cisco.com
 *
 */
(function (global, d3, $) {

    'use strict';

    /**
     * Should debugging mode be turned on|off
     * @type {boolean}
     */
    SevenBridges.DEBUG = false;


    /**
     * UUID of the library: <code>94b2d0d8-99ca-11e5-8994-feff819cdc9f</code>
     * @memberOf SevenBridges
     * @constant {string}
     * @type {string}
     */
    SevenBridges.UUID = "94b2d0d8-99ca-11e5-8994-feff819cdc9f";


    //<editor-fold desc="Polyfills">

    // Credits: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function/bind#Polyfill
    if (!Function.prototype.bind) {
        Function.prototype.bind = function(oThis) {
            if (typeof this !== 'function') {
                // closest thing possible to the ECMAScript 5
                // internal IsCallable function
                throw new TypeError('Function.prototype.bind - what is trying to be bound is not callable');
            }

            var aArgs   = Array.prototype.slice.call(arguments, 1),
                fToBind = this,
                fNOP    = function() {},
                fBound  = function() {
                    return fToBind.apply(this instanceof fNOP
                            ? this
                            : oThis,
                        aArgs.concat(Array.prototype.slice.call(arguments)));
                };

            if (this.prototype) {
                // native functions don't have a prototype
                fNOP.prototype = this.prototype;
            }
            fBound.prototype = new fNOP();

            return fBound;
        };
    }

    // Credits: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/endsWith
    if (!String.prototype.endsWith) {
        String.prototype.endsWith = function(searchString, position) {
            var subjectString = this.toString();
            if (typeof position !== 'number' || !isFinite(position) || Math.floor(position) !== position || position > subjectString.length) {
                position = subjectString.length;
            }
            position -= searchString.length;
            var lastIndex = subjectString.indexOf(searchString, position);
            return lastIndex !== -1 && lastIndex === position;
        };
    }

    // Date.now() definition
    if (!Date.now) {
        Date.now = function () {
            return new Date().getTime();
        };
    }

    //</editor-fold>


    //<editor-fold desc="Script path configurations">

    /**
     * Returns the full path of the script
     * @memberOf SevenBridges
     * @type {string}
     * @constant {string}
     */
    SevenBridges.scriptLocation = (function() {

        // Path of the script
        var srcFullPath = (function() {
            // 1. Check to see if the current script value is set
            if (document && document.currentScript) { // support defer & async
                return document.currentScript.src;
            }

            // 2. Try to fetch the script by its UUID
            var scripts = document.getElementsByTagName('script');
            for (var i = 0, l = scripts.length; i < l; i++) {
                var script = scripts[i];
                if (script.getAttribute('id') == SevenBridges.UUID) {
                    return script.src;
                }
            }

            // 3. Assume the current script is the last script
            //    in DOM tree because of its execution
            return scripts[script.length - 1].src;
        })();

        return srcFullPath.substr(0, srcFullPath.lastIndexOf( '/' ));
    }());


    /**
     * Returns the absolute url
     * @param path
     * @returns {string}
     */
    function retrieveFullQualifiedUrl(path) {
        // Test to see if the path is relative or absolute
        // If it is relative, then prepend the script location.
        // Otherwise return the full qualified URL
        var pat = /^https?:\/\//i;
        if (!pat.test(path))  {
            return SevenBridges.scriptLocation + "/" + path;
        } else {
            return path;
        }
    }

    //</editor-fold>


    //<editor-fold desc="Helpers">

    /**
     * Logging
     */
    var Log = {
        info: function () {
            if (SevenBridges.DEBUG) { console.info.apply(console, arguments); }
        },
        log: function () {
            if (SevenBridges.DEBUG) { console.log.apply(console, arguments); }
        },
        error: function () {
            if (SevenBridges.DEBUG) { console.error.apply(console, arguments); }
        },
        warn: function () {
            if (SevenBridges.DEBUG) { console.warn.apply(console, arguments); }
        }
    };

    /**
     * Math related helper functions
     */
    var MathHelper = {

        /**
         * Checks for the intersection of two lines
         * Credits: http://jsfiddle.net/justin_c_rounds/Gd2S2/
         * @param {number} line1StartX
         * @param {number} line1StartY
         * @param {number} line1EndX
         * @param {number} line1EndY
         * @param {number} line2StartX
         * @param {number} line2StartY
         * @param {number} line2EndX
         * @param {number} line2EndY
         * @returns {{x: null, y: null, onLine1: boolean, onLine2: boolean}}
         */
        checkLineIntersection: function (line1StartX, line1StartY, line1EndX, line1EndY, line2StartX, line2StartY, line2EndX, line2EndY) {
            // if the lines intersect, the result contains the x and y of the intersection
            // (treating the lines as infinite) and booleans for whether line segment 1
            // or line segment 2 contain the point
            var denominator, a, b, numerator1, numerator2, result = {
                x: null,
                y: null,
                onLine1: false,
                onLine2: false
            };
            denominator = ((line2EndY - line2StartY) * (line1EndX - line1StartX)) - ((line2EndX - line2StartX) * (line1EndY - line1StartY));
            if (denominator == 0) {
                return result;
            }
            a = line1StartY - line2StartY;
            b = line1StartX - line2StartX;
            numerator1 = ((line2EndX - line2StartX) * a) - ((line2EndY - line2StartY) * b);
            numerator2 = ((line1EndX - line1StartX) * a) - ((line1EndY - line1StartY) * b);
            a = numerator1 / denominator;
            b = numerator2 / denominator;

            // if we cast these lines infinitely in both directions, they intersect here:
            result.x = line1StartX + (a * (line1EndX - line1StartX));
            result.y = line1StartY + (a * (line1EndY - line1StartY));
            /*
             // it is worth noting that this should be the same as:
             x = line2StartX + (b * (line2EndX - line2StartX));
             y = line2StartX + (b * (line2EndY - line2StartY));
             */
            // if line1 is a segment and line2 is infinite, they intersect if:
            if (a > 0 && a < 1) {
                result.onLine1 = true;
            }
            // if line2 is a segment and line1 is infinite, they intersect if:
            if (b > 0 && b < 1) {
                result.onLine2 = true;
            }
            // if line1 and line2 are segments, they intersect if both of the above are true
            return result;
        },

        /**
         * Computes mid point between two points
         * @param {{x: (number), y: (number)}} p1
         * @param {{x: (number), y: (number)}} p2
         * @returns {number} radians
         */
        midpoint: function (p1, p2) {
            if (p1 && p2) {
                return {
                    x: ((p1.x || 0) + (p2.x || 0)) / 2,
                    y: ((p1.y || 0) + (p2.y || 0)) / 2
                };
            } else {
                return {
                    x: 0,
                    y: 0
                };
            }
        },

        /**
         * Convert radians to degrees
         * @param {number} rad Radians
         * @returns {number}
         */
        toDegrees: function (rad) {
            return rad * (180/Math.PI);
        },

        /**
         * Convert degrees to radians
         * @param {number} deg Degrees
         * @returns {number}
         */
        toRadians: function (deg) {
            return deg * (Math.PI/180);
        },

        /**
         * Computes the angles betwen two points
         * @param {{x: (number), y: (number)}} p1
         * @param {{x: (number), y: (number)}} p2
         * @returns {number} radians
         */
        angleBetweenPoints: function (p1, p2) {
            return Math.atan2(p2.y - p1.y, p2.x - p1.x);
        },

        /**
         * Computes the euclidean distance between two points
         * @param {number} x1
         * @param {number} y1
         * @param {number} x2
         * @param {number} y2
         * @returns {number}
         */
        euclideanDistance: function (x1, y1, x2, y2) {
            return Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
        }
    };

    /**
     * Utility functions
     */
    var Utils = {

        /**
         * Test if the argument is an array
         * @param v
         * @returns {boolean}
         */
        isArray: function (v) {
            // see speed difference: http://stackoverflow.com/a/26633883
            //return (Array.isArray && Array.isArray(v)) || (v instanceof Array);
            return v && v.constructor === Array;
        },

        /**
         * Test if a given number is even
         * @param {number} n Number to test
         * @returns {boolean}
         */
        isEven: function (n) {
            return (n % 2 == 0);
        },

        /**
         * Test if a given number is even
         * @param {number} n Number to test
         * @returns {boolean}
         */
        isOdd: function (n) {
            return (Math.abs(n) % 2 == 1);
        },

        /**
         * Test to see if the object is a number
         * Credits: http://stackoverflow.com/a/1830844
         * @param {*} n
         * @returns {boolean}
         */
        isNumeric: function (n) {
            return isFinite(n) && !isNaN(parseFloat(n));
        },

        /**
         * Test to see if the object is of type function
         * @param callback
         * @returns {boolean}
         */
        isFunction: function (callback) {
            return (callback && typeof callback === 'function');
        },

        /**
         * Test to see if the object is of type string
         * @param obj
         * @returns {boolean}
         */
        isString: function (obj) {
            return typeof obj === 'string' || obj instanceof String;
        },

        /**
         * Trim string
         * Credits: http://blog.stevenlevithan.com/archives/faster-trim-javascript
         * @returns {string} Trimmed string
         */
        strTrim: function(strToTrim) {
            var str = strToTrim.replace(/^\s\s*/, ''),
                ws = /\s/,
                i = str.length;
            while (ws.test(str.charAt(--i))) { }
            return str.slice(0, i + 1);
        },

        /**
         * Test to see if one string contains another
         * @param haystack
         * @param needle
         * @returns {boolean}
         */
        strContains: function(haystack, needle) {
            return haystack.indexOf(needle) !== -1;
        },

        /**
         * Checks if a string is null or whitespace
         * @param  {string}  str String to check
         * @return {boolean}     true or false
         */
        strIsNullOrWhiteSpace: function (str) {
            return (str == null || str.match(/^ *$/) !== null);
        },

        /**
         * Safely convert an object to string
         * @param {*} str
         * @returns {String}
         */
        safeToString: function (obj) {
            return (obj == null) ? '' : obj.toString();
        },

        /**
         * Removes the middle character in the string
         * @param str
         * @returns {string}
         */
        strRemoveMiddleCharacter: function (str) {
            if (str.length <= 0) { return str; }
            else if (str.length == 1) { return ''; }
            else {
                var charPosition = Math.floor(str.length / 2)
                return str.substr(0, charPosition) + str.substr(charPosition + 1);
            }
        },

        /**
         * Insert ellipses in the middle of the string
         * @param {string} str
         * @returns {string}
         */
        strInsertEllipsisInMiddle: function (str) {
            var charPosition = Math.ceil(str.length / 2);
            return str.substr(0, charPosition) + '...' + str.substr(charPosition);
        },

        /**
         * Replace all occurrences of needle in haystack
         * @param {String} str String to do the replacement on
         * @param {String} findStr String to search for
         * @param {String} replacementStr String to use for replacement
         * @returns {XML|void|string}
         */
        strReplaceAll: function (str, findStr, replacementStr){
            return str.replace(new RegExp(this.escapeRegExp(findStr), 'g'), replacementStr);
        },

        /**
         * Escapes a regex string
         * Credits: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Regular_Expressions#Using_Special_Characters
         * @param str
         * @returns {XML|void|string}
         */
        escapeRegExp: function (str) {
            return str.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
        },

        /**
         * Generates an id. Useful for giving DOM elements
         * unique identifiers or anything else that needs
         * a unique identifier.
         *
         * @returns {String} Unique identifier
         */
        generateId: (function() {
            var counter = 1;
            function s4() {
                return Math.floor((1 + Math.random()) * 0x10000).toString(32).substring(1);
            }
            return function () {
                counter = counter + 1;
                return s4() + s4() + s4() + Date.now().toString(32) + counter.toString(32);
            };
        }()),

        /**
         * Given an object, allows you to get/set an object's value using
         * the dot seperated strong
         * Credits: http://stackoverflow.com/a/20125572
         * @param {*} obj Object to search in
         * @param {string} desc Value to get/set
         * @param {*?} value Value to set
         * @returns {*}
         */
        getSetDescendantProp: function (obj, desc, value) {
            var arr = desc ? desc.split(".") : [];

            while (arr.length && obj) {
                var comp = arr.shift();
                var match = new RegExp("(.+)\\[([0-9]*)\\]").exec(comp);

                // handle arrays
                if ((match !== null) && (match.length == 3)) {
                    var arrayData = {
                        arrName: match[1],
                        arrIndex: match[2]
                    };
                    if (obj[arrayData.arrName] !== undefined) {
                        if (typeof value !== 'undefined' && arr.length === 0) {
                            obj[arrayData.arrName][arrayData.arrIndex] = value;
                        }
                        obj = obj[arrayData.arrName][arrayData.arrIndex];
                    } else {
                        obj = undefined;
                    }

                    continue;
                }

                // handle regular things
                if (typeof value !== 'undefined') {
                    if (obj[comp] === undefined) {
                        obj[comp] = {};
                    }

                    if (arr.length === 0) {
                        obj[comp] = value;
                    }
                }

                obj = obj[comp];
            }

            return obj;
        },

        /**
         * Easily iterate over object or array
         * @param obj
         * @param {Function(value,keyOrIndex)} callback
         */
        forEach: function (obj, callback) {
            if (obj && this.isFunction(callback)) {
                if (this.isArray(obj)) {
                    var length = obj.length;
                    for (var i = 0; i < length; i++) {
                        callback(obj[i], i, length);
                    }
                } else {
                    for (var key in obj) {
                        if (obj.hasOwnProperty(key)) {
                            callback(obj[key], key);
                        }
                    }
                }
            }
        },

        /**
         * querySelector() returns all children. This method returns
         * immediate children
         * Credits: http://stackoverflow.com/a/17931569
         * @param element
         * @param selector
         * @returns {*}
         */
        queryChildren: function (element, selector) {
            var count = 0;
            function queryChildren(element, selector) {
                var id = element.id,
                    guid = element.id = id || 'sevenbridges_query_children_' + count++,
                    attr = '#' + guid + ' > ',
                    selector = attr + (selector + '').replace(',', ',' + attr, 'g');
                var result = element.parentNode.querySelectorAll(selector);
                if (!id) element.removeAttribute('id');
                return result;
            }
            return queryChildren(element, selector);
        },

        /**
         * Merges N1, N2, ...Nm deeply-nested JSON objects where N1 is the parent
         *
         * Usage:   https://github.com/justmoon/node-extend#usage
         *
         * Credits: https://github.com/justmoon/node-extend
         */
        extend: function() {
            var hasOwn = Object.prototype.hasOwnProperty;
            var toString = Object.prototype.toString;
            var undefined;

            var isPlainObject = function isPlainObject(obj) {
                if (!obj || toString.call(obj) !== '[object Object]') {
                    return false;
                }

                var has_own_constructor = hasOwn.call(obj, 'constructor');
                var has_is_property_of_method = obj.constructor && obj.constructor.prototype && hasOwn.call(obj.constructor.prototype, 'isPrototypeOf');
                // Not own constructor property must be Object
                if (obj.constructor && !has_own_constructor && !has_is_property_of_method) {
                    return false;
                }

                // Own properties are enumerated firstly, so to speed up,
                // if last one is own, then all properties are own.
                var key;
                for (key in obj) {}

                return key === undefined || hasOwn.call(obj, key);
            };

            var options, name, src, copy, copyIsArray, clone,
                target = arguments[0],
                i = 1,
                length = arguments.length,
                deep = false;

            // Handle a deep copy situation
            if (typeof target === 'boolean') {
                deep = target;
                target = arguments[1] || {};
                // skip the boolean and the target
                i = 2;
            } else if ((typeof target !== 'object' && typeof target !== 'function') || target == null) {
                target = {};
            }

            for (; i < length; ++i) {
                options = arguments[i];
                // Only deal with non-null/undefined values
                if (options != null) {
                    // Extend the base object
                    for (name in options) {
                        src = target[name];
                        copy = options[name];

                        // Prevent never-ending loop
                        if (target === copy) {
                            continue;
                        }

                        // Recurse if we're merging plain objects or arrays
                        if (deep && copy && (isPlainObject(copy) || (copyIsArray = Array.isArray(copy)))) {
                            if (copyIsArray) {
                                copyIsArray = false;
                                clone = src && Array.isArray(src) ? src : [];
                            } else {
                                clone = src && isPlainObject(src) ? src : {};
                            }

                            // Never move original objects, clone them
                            target[name] = this.extend(deep, clone, copy);

                            // Don't bring in undefined values
                        } else if (copy !== undefined) {
                            target[name] = copy;
                        }
                    }
                }
            }

            // Return the modified object
            return target;
        }
    };

    // Expose outside
    SevenBridges.Utils = Utils;

    //</editor-fold>


    //<editor-fold desc="Tooltip">

    /**
     * Tooltip
     * @constructor
     */
    function Tooltip() {
        var self = this;

        /**
         * Unique id of the tooltip
         */
        self.tooltipId = "sb_tooltip_" + Utils.generateId();

        $('body').append('<div id="' + self.tooltipId + '" class="sb-tooltip" style="display:none;"></div>');

        /**
         * The DOM object
         */
        self._$ = $('#' + self.tooltipId);

        /**
         * Hide the tooltip
         */
        self.hide = function () {
            self.detachMouseTracker();
            self._$.hide().html(null);
        };

        /**
         * show the tooltip
         */
        self.show = function (data) {
            self.bindMouseTracker();
            self._$.html(data).show();
        };


        self.bindMouseTracker = function () {
            $(window).on(('mousemove.' + self.tooltipId), function (event) {
                var $this = $(this);
                var xOffset = 10;
                var yOffset = 0;
                var toolTipW = self._$.width();
                var toolTipeH = self._$.height();
                var windowY = $this.scrollTop;
                var windowX = $this.scrollLeft;
                var curX = event.pageX;
                var curY = event.pageY;
                var ttleft = ((curX) > $this.width() / 2) ? curX - toolTipW - xOffset * 2 : curX + xOffset;
                if (ttleft < windowX + xOffset) {
                    ttleft = windowX + xOffset;
                }
                var tttop = ((curY - windowY + yOffset * 2 + toolTipeH) > $this.height()) ? curY - toolTipeH - yOffset * 2 : curY + yOffset;
                if (tttop < windowY + yOffset) {
                    tttop = curY + yOffset;
                }
                self._$.css('top', tttop + 'px').css('left', ttleft + 'px');
            });
        };

        self.detachMouseTracker = function () {
            $(window).off('mousemove.' + self.tooltipId);
        };
    }

    //</editor-fold>


    //<editor-fold desc="D3 Extensions">

    d3.selection.prototype.moveToFront = function() {
        return this.each(function() {
            this.parentNode.appendChild(this);
        });
    };

    d3.selection.prototype.moveToBack = function() {
        return this.each(function() {
            var firstChild = this.parentNode.firstChild;
            if (firstChild) {
                this.parentNode.insertBefore(this, firstChild);
            }
        });
    };

    d3.selection.prototype.selectChildern = function(selector) {
        return d3.select(Utils.queryChildren(this.node(), selector));
    };

    d3.selectChildren = function (selector) {
        return d3.select(Utils.queryChildren(document, selector));
    };

    //</editor-fold>


    //<editor-fold desc="Point">

    /**
     * Definition of a point. Should be used in static manner, i.e. as a
     * function call. The new keyword should not be used
     * @param {number} x
     * @param {number} y
     * @returns {{x: (number), y: (number)}}
     */
    function Point(x, y) {
        return {
            x: x || 0,
            y: y || 0
        };
    }

    //</editor-fold>


    //<editor-fold desc="Node/NodeGroup and related methods/properties">

    /**
     * Description of each node
     * @param {Object} node Data associated with node
     * @constructor
     * @class
     * @global
     */
    function Node(node) {
        var self = this;

        /**
         * Reference to the underlying rendering library's object
         */
        self._ = null;

        self.shouldRenderFabCloud = node.shouldRenderFabCloud || false;

        /**
         * Unique id of each node
         * @type {String}
         */
        self.id = (node && node.hasOwnProperty('id') && !Utils.strIsNullOrWhiteSpace(Node.getNormalizedId(node.id)))
            ? Node.getNormalizedId(node.id)
            : Utils.generateId();

        /**
         * The display name
         * @type {String}
         */
        self.displayName = node.displayName;

        /**
         * The label to use for badging
         * @type {string}
         */
        self.badgeLabel = node.badgeLabel || null;

        /**
         * The tiered position where 1 is the root
         * and all children are 1+n
         * @type {number}
         */
        self.tierLevel = node.tierLevel;

        /**
         * Get the switch role
         * @type {String}
         */
        self.displayIcon = node.displayIcon;

        /**
         * CSS class rules to apply
         * @type {String}
         */
        self.cssClass = node && node.hasOwnProperty('cssClass') && !Utils.strIsNullOrWhiteSpace(node.cssClass) ? node.cssClass : '';

        /**
         * Reference to the source node
         * @type {Node}
         */
        self.parentNode = null;

        /**
         * Reference to the children nodes
         * @type {Array(Node)}
         */
        self.childNodes = [];

        /**
         * Array of all the edges extending out from this node
         * @type {Edge}
         */
        self.edges = [];

        /**
         * Any arbitrary data to associate with each edge
         * @type {Object}
         */
        self.data = node.data || {};

        /**
         * Get the switch / Host badge
         * @type {String}
         */
        self.badge = node.badge;

        /**
         * Node specific flags
         */
        self.flags = Node.getDefaultFlags();

        /**
         * Tags to describe this node
         * @type {{systemDefined: Array, userDefined: Array}}
         */
        self.tags = node.tags || {
                systemDefined: [],
                userDefined: []
            };
    }

    /**
     * Get the default flags
     * @returns {Object}
     * @memberOf Node
     */
    Node.getDefaultFlags = function() {
        return {
            /**
             * Should node be draggable. This property is
             * used in cases where we have a logical node
             * and we don't want the user to drag individual
             * node but instead the node group
             * @type {boolean}
             * @private
             */
            isDraggable: true
        }
    };


    /**
     * Returns the normalized id for a node
     * @param id Id to normalize
     * @returns {string} Normalized id
     * @memberOf Node
     */
    Node.getNormalizedId = function (id) {
        return Utils.safeToString(id).toLowerCase();
    };


    /**
     * Description of each node group
     * @param {Object} node Data associated with node group
     * @constructor
     * @class
     * @global
     */
    function NodeGroup(nodeGroup) {
        var self = this;

        /**
         * Reference to the underlying rendering library's object
         */
        self._ = null;

        /**
         * Unique id of each node
         * @type {String}
         */
        self.id = (nodeGroup && nodeGroup.hasOwnProperty('id') && !Utils.strIsNullOrWhiteSpace(NodeGroup.getNormalizedId(nodeGroup.id)))
            ? NodeGroup.getNormalizedId(nodeGroup.id)
            : Utils.generateId();

        /**
         * Array of all the nodes belonging to this group
         * @type {Node}
         */
        self.nodes = [];

        /**
         * Indicates if the group should be treated as a logical node
         * @type {boolean}
         */
        self.treatAsLogicalNode = Boolean(nodeGroup.treatAsLogicalNode);
    }


    /**
     * Returns the normalized id for a node group
     * @param id Id to normalize
     * @returns {string} Normalized id
     * @memberOf NodeGroup
     */
    NodeGroup.getNormalizedId = function (id) {
        return Utils.safeToString(id).toLowerCase();
    };

    //</editor-fold>


    //<editor-fold desc="Edge/EdgeGroup and related methods/properties">

    /**
     * Description of each edge
     * @param {Node} node1
     * @param {Node} node2
     * @param {Object} edge Any arbitrary data to associate with edge
     * @constructor
     * @class
     * @global
     */
    function Edge(node1, node2, edge) {
        var self = this;

        /**
         * Reference to the underlying rendering library's object
         */
        self._ = null;

        /**
         * Unique id of each edge
         * @type {String}
         */
        self.id = (edge && edge.hasOwnProperty('id') && !Utils.strIsNullOrWhiteSpace(Edge.getNormalizedId(edge.id)))
            ? Edge.getNormalizedId(edge.id)
            : Utils.generateId();

        /**
         * The text tos how on each individual link
         * @type {string}
         */
        self.text = edge.text || null;


        /**
         * Update the text
         * @param {string} text
         */
        self.setText = function(text){
            self.text = text;
        };


        /**
         * CSS class rules to apply
         * @type {String}
         */
        self.cssClass = edge && edge.hasOwnProperty('cssClass') && !Utils.strIsNullOrWhiteSpace(edge.cssClass) ? edge.cssClass : '';

        /**
         * Drawing flags
         */
        self.flags = Edge.getDefaultFlags();

        /**
         * Reference to the source node
         * @type {Node}
         */
        self.srcNode = null;

        /**
         * Reference to the destination node
         * @type {Node}
         */
        self.destNode = null;

        /**
         * Any arbitrary data to associate with each edge
         * @type {Object}
         */
        self.data = edge.data || {};

        /**
         * Used when doing an edge connection to determine
         * the position to draw in a group. This property
         * is set by {@link SevenBridges.prototype.addEdge}
         * @type {number}
         */
        self.multiLinkPositionIndex = 0;

        /**
         * Used when doing an edge connection to determine
         * the total number of edges in a group. This property
         * is set by {@link SevenBridges.prototype.addEdge}
         * @type {number}
         */
        self.multiLinkTotalLinkCount = 0;

        // Set the parent and child node based on
        // the specified tierLevel
        if (node1.tierLevel <= node2.tierLevel) {
            self.srcNode = node1;
            self.destNode = node2;
        } else {
            self.srcNode = node2;
            self.destNode = node1;
        }


        /**
         * Tags to describe this edge
         * @type {{systemDefined: Array, userDefined: Array}}
         */
        self.tags = edge.tags || {
                systemDefined: [],
                userDefined: []
            };
    }


    /**
     * Get the default flags
     * @returns {Object}
     * @memberOf Edge
     */
    Edge.getDefaultFlags = function() {
        return {
            /**
             * Property is set by renderer to determine if the
             * edge has already been drawn
             * @type {boolean}
             * @private
             */
            hasBeenDrawn: false
        };
    };


    /**
     * Returns the normalized if for the edge
     * @param id
     * @returns {string}
     * @memberOf Edge
     */
    Edge.getNormalizedId = function (id) {
        return Utils.safeToString(id).toLowerCase();
    };


    /**
     * Get the hash-map id for nodes
     * @param {string|Node} node1
     * @param {string|Node} node2
     * @returns {string}
     * @memberOf Edge
     */
    Edge.getHashMapKeyBetweenNodes = function (node1, node2) {
        var id1 = (node1 instanceof Node) ? node1.id : node1;
        var id2 = (node2 instanceof Node) ? node2.id : node2;
        return (id1 < id2) ? (id1 + ":" + id2) : (id2 + ":" + id1);
    };


    /**
     * Description of each edge group
     * @param {Object} node Data associated with edge group
     * @constructor
     * @class
     * @global
     */
    function EdgeGroup(edgeGroup) {
        var self = this;

        /**
         * Reference to the underlying rendering library's object
         */
        self._ = null;

        /**
         * CSS class to apply
         */
        self.cssClass = edgeGroup && edgeGroup.hasOwnProperty('cssClass') && !Utils.strIsNullOrWhiteSpace(edgeGroup.cssClass) ? edgeGroup.cssClass : '';

        /**
         * Unique id of each node
         * @type {String}
         */
        self.id = (edgeGroup && edgeGroup.hasOwnProperty('id') && !Utils.strIsNullOrWhiteSpace(EdgeGroup.getNormalizedId(edgeGroup.id)))
            ? EdgeGroup.getNormalizedId(edgeGroup.id)
            : Utils.generateId();

        /**
         * Array of all the nodes belonging to this group
         * @type {Edge}
         */
        self.edges = [];

        /**
         * If the group should be treated as a port channel
         * @type {boolean}
         */
        self.isPortChannel = Boolean(edgeGroup.isPortChannel);

        /**
         * Additional data to associate with the EdgeGroup
         * @type {*|{}}
         */
        self.data = edgeGroup.data || {};
    }


    /**
     * Returns the normalized id for a edge group
     * @param id Id to normalize
     * @returns {string} Normalized id
     * @memberOf EdgeGroup
     */
    EdgeGroup.getNormalizedId = function (id) {
        return Utils.safeToString(id).toLowerCase();
    };

    //</editor-fold>


    //<editor-fold desc="SevenBridges core methods">

    /**
     * Constructor for instantiating a new managed object
     * that handlers node and edge render
     * @param {string} svgContainerId
     * @param {Object} config
     * @constructor
     * @global
     * @class
     */
    function SevenBridges(svgContainerId, config) {
        var self = this;

        /**
         * @type {string}
         */
        self.id = Utils.generateId();

        /**
         * The container that houses the SVG
         * @type {String}
         */
        self.svgContainerId = svgContainerId;

        /**
         * The instance wide defaults
         */
        self.config = Utils.extend(true, {

            /**
             * The relative path of the icons to the current script location
             */
            iconsRelativePath: "assets/images/",

            /**
             * Specifies the zoom scale's allowed range as a two-element array, [minimum, maximum].
             */
            scaleExtent: [0.00000001, 10],

            /**
             * The default animation time to use for transitions
             * @type {number}
             */
            defaultAnimationTime: 350,

            /**
             * The type of layout to use for rendering. The following
             * layouts are supported:
             * - radial
             * - circular
             * - tiered-left-right
             * - tiered-top-down
             * @type {string}
             */
            renderingLayout: 'force-directed',

            /**
             * List of properties the search will use
             */
            searchableProperties: [
                "displayName",
                //"id",
                "srcNode.displayName",
                "destNode.displayName"
            ],

            /**
             * Stylings
             */
            style: {

                /**
                 * The default icon to use for the nodes
                 * @type {string}
                 */
                defaultNodeIcon: 'fiext-switch-normal',

                /**
                 * Curved or straight
                 * @type {string}
                 */
                edgeConnectionType: 'curved',

                /**
                 * Specifies the spacing between each edge
                 * when multi-link is drawn
                 * @type {number}
                 */
                multiLinkEdgeSpacing: 3.5,

                /**
                 * Spacing to use for nodes in the x-axis
                 * @type {number}
                 */
                nodeSpacingX: 200,

                /**
                 * Spacing to use for the different tiers
                 * @type {number}
                 */
                nodeSpacingY: 250,

                /**
                 * The max number of leaves to show in one row before splitting into multiple rows
                 * @type {number}
                 */
                tierSplitNumber: 16,

                /**
                 * The default tier-level for leaves
                 * @type {number}
                 */
                defaultLeavesTierLevel: 3
            },

            /**
             * Tooltip formatters
             */
            tooltip: {
                /**
                 * HTML formatter for when node's tooltip is called
                 * @param {Node} node
                 * @returns {string} html
                 */
                nodeHtmlFormatter: function (node) {
                    return node.displayName;
                },

                /**
                 * Hook for when edge's tooltip is called
                 * @param {Edge} edge
                 * @returns {string} html
                 */
                edgeHtmlFormatter: function (edge) {
                    return edge.srcNode.displayName + " &#8596; " + edge.destNode.displayName;
                },

                /**
                 * Hook for when edgeGroup's tooltip is called
                 * @param {EdgeGroup} edgeGroup
                 * @returns {string} html
                 */
                edgeGroupHtmlFormatter: function (edgeGroup) {
                    return edgeGroup;
                }
            },

            /**
             * Specifies whether the node text should be trimmed by removing the middle characters
             */
            trimNodeText: true

        }, config);


        d3.select(self.svgContainerId).classed('sb-wrapper', true);

        /**
         * The object of the underlying graphics
         * rendering library
         */
        self._ = d3.select(self.svgContainerId).append('svg')
            .attr('id', self.id)
            .classed('sb-svg-canvas', true); // .attr('preserveAspectRatio', 'none slice')

        /**
         * The root group that houses everything
         */
        self._root = self._.append('svg:g');

        /**
         * Map of all the nodes. Nodes can be fetched
         * using the key of each node
         * @type {{id: Node}}
         */
        self.nodes = {};

        /**
         * Map of all the node groups that exist with in the topology.
         * Each group contains a {@link NodeGroup} object which has
         * references to all individual {@link Node}.
         * @type {{id: NodeGroup}}
         */
        self.nodeGroups = {};

        /**
         * Map of all the edges. Edges can be fetched
         * using the key/id of each node.
         * @type {Edge}
         */
        self.edges = {};

        /**
         * Map of all the edge groups that exist with in the topology.
         * Each group contains a {@link EdgeGroup} object which has
         * references to all individual {@link Edge}.
         * @type {{id: EdgeGroup}}
         */
        self.edgeGroups = {};

        /**
         * Okay, I know this is a bit ugly but bare with me. The key
         * for map can be computed using {@link Edge.getHashMapKeyBetweenNodes}
         * The returned object is an array list of all the edges
         * between node1 and node2.
         * To iterate all the edges. You can simply iterate
         * over this map and then over each array item or using the
         * utility method {@link #forEachEdge}
         * We need this do compute the count of edges between
         * two nodes for multi-link edges and for searching
         * @type {Object.<string, Edge>}
         */
        self.edgeConnections = {};

        /**
         * Indicates if the node is in drag
         * @type {boolean}
         */
        self.flagIsInNodeDrag = false;

        /**
         *
         * @type {Object.<string, {node: Array, edge: Array}>}
         */
        self.userRegisteredEventListeners = {};

        /**
         * Custom event dispatcher
         */
        self.dispatcher = d3.dispatch("drawstart", "drawfinish", "onselectionend");

        /**
         * Default zoom event handler
         */
        self.zoomEventHandler = d3.behavior.zoom().scaleExtent(self.config.scaleExtent)
            .on("zoomstart.sb_root", function () { self._onZoomStart(this);})
            .on("zoom.sb_root", function () { self._onZoom(this);})
            .on("zoomend.sb_root", function () { self._onZoomEnd(this);});

        /**
         * Drag event handler
         */
        self.dragEventHandler = d3.behavior.drag()
            .on("dragstart.sb_root", function () {
                if (!self.flagIsInSelectionMode) { self._onNodeDragStart(this); }
            })
            .on("drag.sb_root", function () { if (!self.flagIsInSelectionMode) { self._onNodeDrag(this); }})
            .on("dragend.sb_root", function () { if (!self.flagIsInSelectionMode) { self._onNodeDragEnd(this); }});

        /**
         * Tooltip
         * @type {Tooltip}
         */
        self.tooltip = new Tooltip();


        // Tooltip binding
        (function () {
            self.on('node_mouseover.unite_tooltip', function (node) {
                if (Utils.isFunction(self.config.tooltip.nodeHtmlFormatter)) {
                    self.tooltip.show(self.config.tooltip.nodeHtmlFormatter(node));
                }
            });

            self.on('node_mouseleave.unite_tooltip', function (node) {
                self.tooltip.hide();
            });

            self.on('edge_mouseover.unite_tooltip', function (edge) {
                if (Utils.isFunction(self.config.tooltip.edgeHtmlFormatter)) {
                    self.tooltip.show(self.config.tooltip.edgeHtmlFormatter(edge));
                }
            });

            self.on('edge_mouseleave.unite_tooltip', function (edge) {
                self.tooltip.hide();
            });

            self.on('edgegroup_mouseover.unite_tooltip', function (edgeGroup) {
                if (Utils.isFunction(self.config.tooltip.edgeGroupHtmlFormatter)) {
                    self.tooltip.show(self.config.tooltip.edgeGroupHtmlFormatter(edgeGroup));
                }
            });

            self.on('edgegroup_mouseleave.unite_tooltip', function (edgeGroup) {
                self.tooltip.hide();
            });
        })();
    }


    /**
     * Override the default configuration
     * @param {Object} config Configuration
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.withConfig = function(config) {
        Utils.extend(true, this.config, config);
        return this;
    };


    //<editor-fold desc="Instance utilities">

    /**
     * Utility method to iterate the node set easily
     *
     * @param {function(Node)} callback Callback for each iteration
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.forEachNode = function(callback) {
        var self = this;
        if (Utils.isFunction(callback)) {
            var nodesMap = self.nodes,
                nodeKeys = Object.getOwnPropertyNames(nodesMap);
            for (var i = 0; i < nodeKeys.length; i++) {
                callback(nodesMap[nodeKeys[i]]);
            }
        }
        return self;
    };


    /**
     * Utility method to iterate the node group set easily
     *
     * @param {function(NodeGroup)} callback Callback for each iteration
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.forEachNodeGroup = function(callback) {
        var self = this;
        if (Utils.isFunction(callback)) {
            var nodesGroupMap = self.nodeGroups,
                nodeKeys = Object.getOwnPropertyNames(nodesGroupMap);
            for (var i = 0; i < nodeKeys.length; i++) {
                callback(nodesGroupMap[nodeKeys[i]]);
            }
        }
        return self;
    };


    /**
     * Utility method to iterate the edge set easily
     *
     * @callback {function(Edge, number, Number)} callback
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.forEachEdge = function(callback) {
        var self = this;
        if (Utils.isFunction(callback)) {
            var edgesMap = self.edgeConnections,
                edgeKeys = Object.getOwnPropertyNames(edgesMap);

            for (var i = 0; i < edgeKeys.length; i++) {
                var edgesArr = edgesMap[edgeKeys[i]];
                if (edgesArr && edgesArr.length > 0) {
                    var length = edgesArr.length;
                    for (var j = 0; j < length; j++) {
                        callback(edgesArr[j], j, length);
                    }
                }
            }
        }
        return self;
    };


    /**
     * Utility method to iterate the edge group set easily
     *
     * @callback {function(EdgeGroup)} callback Callback for each iteration
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.forEachEdgeGroup = function(callback) {
        var self = this;
        if (Utils.isFunction(callback)) {
            var edgesGroupMap = self.edgeGroups,
                edgeKeys = Object.getOwnPropertyNames(edgesGroupMap);
            for (var i = 0; i < edgeKeys.length; i++) {
                callback(edgesGroupMap[edgeKeys[i]]);
            }
        }
        return self;
    };


    /**
     * Add a class to all nodes
     * @param {String} className
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.addClassToNodes = function (className) {
        var self = this;
        self.forEachNode(function (node) {
            if (node && node._) {
                node._.classed(className, true);
            }
        });
        return self;
    };


    /**
     * Removes a class from all nodes
     * @param className
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.removeClassFromNodes = function (className) {
        var self = this;
        self.forEachNode(function (node) {
            if (node && node._) {
                node._.classed(className, false);
            }
        });
        return self;
    };


    /**
     * Add a class to all edges
     * @param {String} className
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.addClassToEdges = function (className) {
        var self = this;
        self.forEachEdge(function (edge) {
            if (edge && edge._) {
                edge._.classed(className, true);
            }
        });
        return this;
    };


    /**
     * Removes a class from all edges
     * @param className
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.removeClassFromEdges = function (className) {
        var self = this;
        self.forEachEdge(function (edge) {
            if (edge && edge._) {
                edge._.classed(className, false);
            }
        });
        return this;
    };

    //</editor-fold>


    /**
     * Moves an element right behind the first node or nodeGroup
     * @param {Element} elemn
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._moveRightBehindFirstNodeOrNodeGroup = function(elemn) {
        var self = this,
            firstNode = self._root.select('.sb-node').node(),
            firstNodeGroup = self._root.select('.sb-node-group').node(),
            childNodes = self._root.node().childNodes;

        // Index of node: http://stackoverflow.com/a/9132575
        var ifirstNode = Array.prototype.indexOf.call(childNodes, firstNode);
        var ifirstNodeGroup = Array.prototype.indexOf.call(childNodes, firstNodeGroup);

        if (ifirstNode < ifirstNodeGroup) {
            self._root.node().insertBefore(elemn, firstNode || firstNodeGroup);
        } else {
            self._root.node().insertBefore(elemn, firstNodeGroup || firstNode);
        }

        return self;
    };


    //<editor-fold desc="Data set manipulation/access">

    /**
     * Clears any stored data
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.clearData = function () {
        var self = this;
        self.nodes = {};
        self.nodeGroups = {};
        self.edges = {};
        self.edgeGroups = {};
        self.edgeConnections = {};
        self._clearDrawingSurface();
        return self;
    };


    /**
     * Add a node or nodes
     * @param {Object|Array} nodeOrNodes Description of each node
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.addNodes = function (nodeOrNodes) {
        var self = this;

        // Safely push the node to nodes list
        function safePushNode(data) {
            if (data) {
                var node = new Node(data),
                    id = node.id;
                // Remove existing node if it already exists
                if (self.nodes[id]) { self.removeNodesById(id, true); }
                // Push to myself
                self.nodes[id] = node;
            }
        }

        // if the element exists
        if (nodeOrNodes) {
            if (Utils.isArray(nodeOrNodes)) {
                Utils.forEach(nodeOrNodes, function (node) {
                    safePushNode(node);
                });
            } else {
                safePushNode(nodeOrNodes);
            }
        }

        return self;
    };


    /**
     * Add a node group or groups
     * @param nodeOrNodes
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.addNodeGroups = function (nodeGroupOrGroups) {
        var self = this;

        // Safely push the node to nodes list
        function safePushNodeGroup(data) {
            if (data) {
                var nodeGroup = new NodeGroup(data),
                    id = nodeGroup.id;

                // Push to the nodes group
                self.nodeGroups[id] = nodeGroup;

                // Iterate through all the nodes
                Utils.forEach(data.nodeIds, function (id) {
                    var node = self.fetchNodeById(id);
                    if (node) { nodeGroup.nodes.push(node); }
                });
            }
        }

        // if the element exists
        if (nodeGroupOrGroups) {
            if (Utils.isArray(nodeGroupOrGroups)) {
                Utils.forEach(nodeGroupOrGroups, function (nodeGroup) {
                    safePushNodeGroup(nodeGroup);
                });
            } else {
                safePushNodeGroup(nodeGroupOrGroups);
            }
        }

        return self;
    };


    /**
     * Add an edge or edges
     * @param {Object|Array} edgeOrEdges Description of each edge
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.addEdges = function (edgeOrEdges) {
        var self = this;

        // Safely push the edge to edge lists
        function safePushEdge(edge) {
            if (edge) {
                var srcNode = self.nodes[Node.getNormalizedId(edge.srcId)],
                    destNode = self.nodes[Node.getNormalizedId(edge.destId)];

                if (srcNode && destNode) {
                    var edgeObj = new Edge(srcNode, destNode, edge),
                        hashMapKey = Edge.getHashMapKeyBetweenNodes(srcNode, destNode),
                        edgesArr = self.edgeConnections[hashMapKey];
                    srcNode.edges.push(edgeObj);
                    destNode.edges.push(edgeObj);

                    // If the array at hashMapKey does not exist,
                    // initialize the object
                    if (!edgesArr) {
                        self.edgeConnections[hashMapKey] = [];
                        edgesArr = self.edgeConnections[hashMapKey];
                    }

                    // Add edge to the map
                    edgesArr.push(edgeObj);

                    // Go through all the edges to specify a multiplicity
                    // and set the property on each node
                    Utils.forEach(edgesArr, function (edge, i, length) {
                        edge.multiLinkPositionIndex = i;
                        edge.multiLinkTotalLinkCount = length;
                    });

                    self.edges[edgeObj.id] = edgeObj;
                }
            }
        }

        // if element exists
        if (edgeOrEdges) {
            if (Utils.isArray(edgeOrEdges)) {
                Utils.forEach(edgeOrEdges, function (edge) {
                    safePushEdge(edge);
                });
            } else {
                safePushEdge(edgeOrEdges);
            }
        }

        return self;
    };


    /**
     * Add a edge group or groups
     * @param edgeGroupOrGroups
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.addEdgeGroups = function (edgeGroupOrGroups) {
        var self = this;

        // Safely push the edge to edges group
        function safePushEdgeGroup(data) {
            if (data) {
                var edgeGroup = new EdgeGroup(data),
                    id = edgeGroup.id;

                // Push to the edges group
                self.edgeGroups[id] = edgeGroup;

                // Iterate through all the edges
                Utils.forEach(data.edgeIds, function (id) {
                    var edge = self.fetchEdgeById(id);
                    if (edge) { edgeGroup.edges.push(edge); }
                });
            }
        }

        // if the element exists
        if (edgeGroupOrGroups) {
            if (Utils.isArray(edgeGroupOrGroups)) {
                Utils.forEach(edgeGroupOrGroups, function (edgeGroup) {
                    safePushEdgeGroup(edgeGroup);
                });
            } else {
                safePushEdgeGroup(edgeGroupOrGroups);
            }
        }

        return self;
    };


    /**
     * Fetch a node by it's given id
     * @param {String} id
     * @returns {Node}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.fetchNodeById = function (id) {
        return this.nodes[Node.getNormalizedId(id)];
    };

    /**
     * Fetch a node group by it's given id
     * @param {String} id
     * @returns {NodeGroup}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.fetchNodeGroupById = function (id) {
        return this.nodeGroups[NodeGroup.getNormalizedId(id)];
    };


    /**
     * Fetch an edge by it's given id
     * @param {String} id
     * @returns {Edge}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.fetchEdgeById = function (id) {
        return this.edges[Edge.getNormalizedId(id)];
    };


    /**
     * Fetch list of edges between two nodes
     * @param {Node|string} nodeId1
     * @param {Node|string} nodeId2
     * @returns {Edge[]}
     */
    SevenBridges.prototype.fetchEdgesBetweenNode = function (nodeId1, nodeId2) {
        return this.edgeConnections[Edge.getHashMapKeyBetweenNodes(nodeId1, nodeId2)];
    };


    /**
     * Fetch an edgeGroup by it's given id
     * @param {String} id
     * @returns {EdgeGroup}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.fetchEdgeGroupById = function (id) {
        return this.edgeGroups[EdgeGroup.getNormalizedId(id)];
    };


    /**
     * Remove node or nodes by given id
     * @param {String|Array} nodeToRemoveIds Id or ids of nodes to remove
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.removeNodesById = function (nodeToRemoveIds) {
        var self = this,
            nodes = self.nodes;

        // Safely remove the node if it exists
        // by a given id
        function safeRemoveNode(id) {
            id = Node.getNormalizedId(id);
            var node = nodes[id];
            if (node) {
                // Remove all the edges
                // for(var i = node.edges.length - 1; i >= 0; i--) { node.edges.splice(i, 1); }
                var edgesIds = [];
                Utils.forEach(node.edges, function (edge) {
                    edgesIds.push(edge.id);
                });
                self.removeEdgesById(edgesIds);

                if (node._) {
                    try { node._.node().remove(); }
                    catch (err) { Log.error(err); }
                }

                // Now delete the node
                delete nodes[id];
            }
        }

        // Iterate to remove all the nodes by give id(s)
        if (nodeToRemoveIds) {
            if (Utils.isArray(nodeToRemoveIds) && nodeToRemoveIds.length > 0) {
                Utils.forEach(nodeToRemoveIds, function (id) {
                    safeRemoveNode(id);
                });
            } else {
                safeRemoveNode(nodeToRemoveIds);
            }
        }

        return self;
    };


    /**
     * Remove edge or edges by given id
     * @param {string|Array<string>} edgesToRemoveIds Id or ids of edges to remove
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.removeEdgesById = function (edgesToRemoveIds) {
        var self = this,
            edges = self.edges;

        // Safely remove the edge if it exists
        // by a given id
        function safeRemoveEdge(id) {
            id = Edge.getNormalizedId(id);
            var edge = edges[id];
            if (edge) {
                // Remove references from the src node
                var srcNodeEdges = edge.srcNode.edges;
                for (var i = srcNodeEdges.length - 1; i >= 0; i--) {
                    var edgee = srcNodeEdges[i];
                    if (edgee && edgee.id == id) {
                        srcNodeEdges.splice(i, 1);
                        if (edgee._) {
                            try { edgee._.node().remove(); }
                            catch (err) { Log.error(err); }
                        }
                    }
                }

                // Remove references from the dest node
                var destNodeEdges = edge.destNode.edges;
                for (var i = destNodeEdges.length - 1; i >= 0; i--) {
                    var edgee = destNodeEdges[i];
                    if (edgee && edgee.id == id) {
                        destNodeEdges.splice(i, 1);
                        if (edgee._) {
                            try { edgee._.node().remove(); }
                            catch (err) { Log.error(err); }
                        }
                    }
                }

                // clean up any reference in edge groups
                var edgesGroupMap = self.edgeGroups;
                var edgesGroupMapKeys = Object.getOwnPropertyNames(edgesGroupMap);
                for (var i = 0; i < edgesGroupMapKeys.length; i++) {
                    var edgeGroup = edgesGroupMap[edgesGroupMapKeys[i]];
                    for (var j = edgeGroup.edges.length - 1; j >= 0; j--) { // iterate over all the edges
                        var edgee = edgeGroup.edges[j];
                        if (edgee.id == id) {
                            edgeGroup.edges.splice(j, 1);
                        }
                    }
                }

                // remove from edge connections
                delete self.edgeConnections[Edge.getHashMapKeyBetweenNodes(edge.srcNode, edge.destNode)];

                // Now delete the edge
                delete edges[id];
            }
        }

        // Iterate to remove all the nodes by give id(s)
        if (edgesToRemoveIds) {
            if (Utils.isArray(edgesToRemoveIds) && edgesToRemoveIds.length > 0) {
                Utils.forEach(edgesToRemoveIds, function (id) {
                    safeRemoveEdge(id);
                });
            } else {
                safeRemoveEdge(edgesToRemoveIds);
            }
        }

        return self;
    };


    /**
     * Should be called every time the dataset, either
     * node set or edge set changes
     * @param {boolean} preserveCurrentPositionOfNodes Whether the current position should be
     *                          preserved when redrawing.
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.notifyDataSetChanged = function (preserveCurrentPositionOfNodes) {
        var self = this;
        var edgesMap = self.edgeConnections;
        var edgeGroups = self.edgeGroups;

        // Create an array of all the edges sorted by edge group for sorting
        var allEdges = [];
        for (var group in edgeGroups) {
            for (var e = 0; e < edgeGroups[group].edges.length; e++) {
                allEdges.push(edgeGroups[group].edges[e].id);
            }
        }

        // Sort edgesMap in order of edgeGroups
        var sorting = allEdges;
        var result = [];
        for (var edgeSet in edgesMap) {
            var items = edgesMap[edgeSet];
            result = items.map(function(item) {
                var n = sorting.indexOf(item.id);
                sorting[n] = '';
                return [n, item]
            }).sort().map(function(edgeSet) { return edgeSet[1] })

            edgesMap[edgeSet] = result;
        }

        for (var edgeSet in edgesMap) {
            var i = 0;
            for (var e = 0; e < edgesMap[edgeSet].length; e++) {
                edgesMap[edgeSet][e].multiLinkPositionIndex = i;
                i++;
            }
        }

        self.redraw(preserveCurrentPositionOfNodes);
        return self;
    };

    //</editor-fold>


    //<editor-fold desc="Eventing">

    /**
     * Bind event handlers
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._bindEventHandlers = function () {
        var self = this;

        // Bind zoom functionality
        self._.call(self.zoomEventHandler)
            .on("dblclick.zoom", null); // Disable double-click zoom


        // Event handler for selection
        self._.on('mousedown.sb_intl_selection_mouse', function () {
            if (self.flagIsInSelectionMode && !d3.event.metaKey) {
                self._onSelectionStart(d3.event);
            }
        }).on('mousemove.sb_intl_selection_mouse', function () {
            if (self.flagIsInSelectionMode && !d3.event.metaKey) {
                self._onSelection(d3.event);
            }
        }).on('mouseup.sb_intl_selection_mouse', function () {
            if (self.flagIsInSelectionMode && !d3.event.metaKey) {
                self._onSelectionEnd(d3.event);
            }
        });

        self.forEachNode(function (node) {
            node._.on('click.sb_intl_selection_click', function () {
                if (self.flagIsInSelectionMode && d3.event.metaKey) {
                    d3.event.stopPropagation();
                    d3.event.preventDefault();
                    self._onSelectionNodeClick(node);
                }
            });
        });


        self.dispatcher.on('drawstart', function () {
            self._on("canvas", "drawstart", null, this);
        });

        self.dispatcher.on('drawfinish', function () {
            self._on("canvas", "drawfinish", null, this);
        });

        self.dispatcher.on('onselectionend', function () {
            self._on("canvas", "onselectionend", null, this);
        });


        // Bind to the group first
        self.forEachNodeGroup(function (nodeGroup) {
            if (nodeGroup.treatAsLogicalNode) {
                nodeGroup._.call(self.dragEventHandler);
                Utils.forEach(nodeGroup.nodes, function (node) {
                    node.flags.isDraggable = false;
                });
            }
        });

        self.forEachEdgeGroup(function (edgeGroup) {
            edgeGroup._.ellipse
                .on("mousedown.sb_edgegroup", function() { self._on("edgegroup", "mousedown",   edgeGroup, this); })
                .on("mouseup.edgegroup",      function() { self._on("edgegroup", "mouseup",     edgeGroup, this); })
                .on("click.edgegroup",        function() { self._on("edgegroup", "click",       edgeGroup, this); })
                .on("dblclick.edgegroup",     function() { self._on("edgegroup", "dblclick",    edgeGroup, this); })
                .on("contextmenu.edgegroup",  function() {
                    self._on("edgegroup", "rightclick",  edgeGroup, this);
                    self._on("edgegroup", "contextmenu", edgeGroup, this);
                })
                .on("mouseover.edgegroup",    function() { self._on("edgegroup", "mouseover",   edgeGroup, this); })
                .on("mouseout.edgegroup",     function() { self._on("edgegroup", "mouseout",    edgeGroup, this); })
                .on("mouseenter.edgegroup",   function() { self._on("edgegroup", "mouseenter",  edgeGroup, this); })
                .on("mouseleave.edgegroup",   function() { self._on("edgegroup", "mouseleave",  edgeGroup, this); });
        });


        // Bind handlers to the nodes
        self.forEachNode(function (node) {
            // Bind all left-over nodes to drag event-handler
            if (node.flags.isDraggable) {
                node._.call(self.dragEventHandler);
            }

            // Attach listeners
            node._.on("mousedown.sb_node",  function() { self._on("node", "mousedown",   node, this); })
                .on("mouseup.sb_node",      function() { self._on("node", "mouseup",     node, this); })
                .on("click.sb_node",        function() {
                    if (d3.event.defaultPrevented || self.flagIsInSelectionMode) { return; }
                    self._on("node", "click", node, this);
                })
                .on("dblclick.sb_node",     function() {
                    if (d3.event.defaultPrevented || self.flagIsInSelectionMode) return;
                    self._on("node", "click", node, this);
                })
                .on("contextmenu.sb_node",  function() {
                    if (d3.event.defaultPrevented || self.flagIsInSelectionMode) return;
                    self._on("node", "rightclick", node, this);
                    self._on("node", "contextmenu", node, this);
                })
                .on("mouseover.sb_node",    function() { self._on("node", "mouseover",   node, this); })
                .on("mouseout.sb_node",     function() { self._on("node", "mouseout",    node, this); })
                .on("mouseenter.sb_node",   function() { self._on("node", "mouseenter",  node, this); })
                .on("mouseleave.sb_node",   function() { self._on("node", "mouseleave",  node, this); })
        });

        // Bind handlers to the edges
        self.forEachEdge(function (edge) {
            // Attach listeners
            edge._.on("mousedown.sb_edge",  function() { self._on("edge", "mousedown",   edge, this); })
                .on("mouseup.sb_edge",      function() { self._on("edge", "mouseup",     edge, this); })
                .on("click.sb_edge",        function() { self._on("edge", "click",       edge, this); })
                .on("dblclick.sb_edge",     function() { self._on("edge", "dblclick",    edge, this); })
                .on("contextmenu.sb_edge",  function() {
                    self._on("edge", "rightclick",  edge, this);
                    self._on("edge", "contextmenu", edge, this);
                })
                .on("mouseover.sb_edge",    function() { self._on("edge", "mouseover",   edge, this); })
                .on("mouseout.sb_edge",     function() { self._on("edge", "mouseout",    edge, this); })
                .on("mouseenter.sb_edge",   function() { self._on("edge", "mouseenter",  edge, this); })
                .on("mouseleave.sb_edge",   function() { self._on("edge", "mouseleave",  edge, this); })
        });

        return self;
    };


    /**
     * Handler that dispatches to the user's listeners
     * @param {String} eventType The type. Either 'node' or 'edge'
     * @param {String} eventName The name of the underlying event
     * @param {Object} sbObject data to pass
     * @param that The 'this' context
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._on = function(eventType, eventName, sbObject, that) {
        var self = this;

        // If the event is registered, look up the event and dispatch listeners
        if (self.userRegisteredEventListeners[eventType] && self.userRegisteredEventListeners[eventType][eventName]) {
            var eventListeners = self.userRegisteredEventListeners[eventType][eventName];
            Utils.forEach(eventListeners, function (listener) {
                listener.call(that, sbObject);
            });
        }

        return self;
    };


    /**
     * Register an event listener. The attach method supports
     * @param {String} eventName Name of the event. Events can be namespaced
     * @param {Function} callback Function to invoke
     * @returns {SevenBridges} Reference to self for chaining
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.on = function(eventName, callback) {
        var self = this;

        /**
         * Extract information about the event name
         * @param {string} str Event name to parse
         * @returns {{type: (string), eventName:  (string), namespace:  (string)}}
         */
        function customEventNameParser(str) {
            var regexExpression = /^(\w+)(\_)(\w+)(\.*)(\w*)$/,
                match = regexExpression.exec(str);

            if (match !== null) {
                return {
                    type: match[1],
                    eventName: match[3],
                    namespace: match[5] || '__default_namespace__'
                };
            }

            return null;
        }

        // Push or delete the listener
        if (!Utils.strIsNullOrWhiteSpace(eventName)) {
            // Parse the event name and get the normalized event object
            var eventInfo = customEventNameParser(eventName);
            if (eventInfo != null) {
                // If object is not defined, define it
                if (!self.userRegisteredEventListeners[eventInfo.type]) { self.userRegisteredEventListeners[eventInfo.type] = {}; }
                if (!self.userRegisteredEventListeners[eventInfo.type][eventInfo.eventName]) { self.userRegisteredEventListeners[eventInfo.type][eventInfo.eventName] = {}; }

                // Either remove the callback if null is passed
                // or add callback
                if (callback == null) {
                    delete self.userRegisteredEventListeners[eventInfo.type][eventInfo.eventName][eventInfo.namespace];
                } else if (Utils.isFunction(callback)) {
                    self.userRegisteredEventListeners[eventInfo.type][eventInfo.eventName][eventInfo.namespace] = callback;
                }
            }
        }

        return self;
    };

    //</editor-fold>


    //<editor-fold desc="Rendering">

    /**
     * Bounding box coordinates are relative to the viewport.
     * If any transformations are applied to the parent group,
     * coordinates are not spaced correct. This function returns
     * coordinates that account for any transformations.
     * @param {number} x The x-coordinate
     * @param {number} y The y-coordinate
     * @param {d3.transform} transform
     * @returns {{x: number, y: number}}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._getResolvedCoordinates = function (x, y, transform) {
        transform = !transform ? d3.transform(self._root ? self._root.attr('transform') : '') : transform;
        return {
            x: (x - transform.translate[0])/transform.scale[0],
            y: (y - transform.translate[1])/transform.scale[1]
        };
    };


    /**
     * Clear the drawing surface
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._clearDrawingSurface = function () {
        var self = this;

        // Remove all children
        self._.selectAll("*").remove();

        // The root group housing everything
        self._root = self._.append('svg:g');

        // Clear all drawing flags
        self._clearAllDrawingFlags();

        return self;
    };


    /**
     * Clear all drawing flags
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._clearAllDrawingFlags = function () {
        var self = this;

        self.flagIsInNodeDrag = false;

        // Apply the default flags
        self.forEachNode(function (node) {
            node._ = null;
            node.flags = Node.getDefaultFlags();
        });

        self.forEachNodeGroup(function (nodeGroup) {
            nodeGroup._ = null;
            nodeGroup.treatAsLogicalNode = false;
        });

        // Clear all the flags from edges
        self.forEachEdge(function (edge) {
            edge._ = null;
            edge.flags = Edge.getDefaultFlags();
        });

        self.forEachEdgeGroup(function (edgeGroup) {
            edgeGroup._ = null;
        });

        return self;
    };


    /**
     * Redraws the entire canvas
     * @param {boolean} preserveCurrentPositionOfNodes Whether the current position should be
     *                          preserved when redrawing.
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.redraw = function (preserveCurrentPositionOfNodes) {
        var self = this;

        self.dispatcher.drawstart();

        // The current layout position
        var savedLayoutString = preserveCurrentPositionOfNodes ? self.getSaveLayoutString() : null;

        // Clear the drawing surface before re-rendering
        self._clearDrawingSurface();

        // Do the drawing
        self._drawNodes()
            //._drawNodeGroups() // TODO: Removing this functionality for now
            ._drawEdges();

        if (preserveCurrentPositionOfNodes) {
            self.applySavedLayout(savedLayoutString);
        } else {
            self._applyLayout();
        }

        self._redrawEdgePathConnection()
            ._drawEdgeGroups()
            ._bindEventHandlers()
            ._redrawEdgePathConnection();

        return self;
    };

    //</editor-fold>


    //<editor-fold desc="Layout managers">

    SevenBridges.prototype.layouts = SevenBridges.prototype.layouts || [];

    /**
     * Apply layout
     * @param {string} layout Layout to apply
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._applyLayout = function (layout) {
        try {
            this.layouts[layout || this.config.renderingLayout].call(this);
        } catch (err) {
            console.error('Failed to apply layout', arguments);
            console.error('Current layouts', this.layouts);
            throw err;
        }
        return this;
    };


    /**
     * Applies circular layout
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.layouts["circular"] = function () {
        var self = this;

        var SPACING_X = self.config.style.nodeSpacingX;

        var nodeNumber = Object.getOwnPropertyNames(self.nodes).length;
        var radius = nodeNumber * SPACING_X * 2 / ( 2 * Math.PI );
        var angle = 360 / nodeNumber;
        var nodecount = 0;


        self.forEachNode(function (node) {
            var nodeAngle = angle * nodecount++;
            var nodeRadians = MathHelper.toRadians(nodeAngle);
            var xpos = radius * Math.cos(nodeRadians);
            var ypos = radius * Math.sin(nodeRadians);
            node._.attr("transform", "translate(" + xpos + "," + ypos + ")");
        });

        self.zoomFit();


        return self;
    };


    /**
     * Applies Tiered circular layout
     * @returns {SevenBridges}
     * @private
     */
    SevenBridges.prototype.layouts["tiered-circular"] = function () {
        var self = this;

        var SPACING_X = self.config.style.nodeSpacingX;
        var SPACING_Y = self.config.style.nodeSpacingY;

        var perTierNodeCount = {};
        var tierAngles = {};
        var tierRadius = {};
        var tierNodeCount = {};
        var actualperTierNodeCount = {};
        var tierOffsetY = {};
        var widestTier = 0;

        // Calculate positions

        var nodesMap = self.nodes,
            nodeKeys = Object.getOwnPropertyNames(nodesMap);
        for (var i = 0; i < nodeKeys.length; i++) {
            var node = nodesMap[nodeKeys[i]];
            var count = perTierNodeCount[node.tierLevel] || 0;
            perTierNodeCount[node.tierLevel] = ++count;
        }
        var tierkeys = Object.getOwnPropertyNames(perTierNodeCount);
        var radius = SPACING_Y;
        for(var i=0; i<tierkeys.length; i++){
            tierAngles[tierkeys[i]] = 360 / perTierNodeCount[tierkeys[i]] ;
            if(i==0 ){
                if(perTierNodeCount[tierkeys[i]] == 1) {
                    radius=0;

                }
                tierRadius[tierkeys[i]] = radius;
            }else{
                var radiusinc = perTierNodeCount[tierkeys[i]]* SPACING_X / ( 2 * Math.PI );
                radius = radiusinc + radius + 100;
                tierRadius[tierkeys[i]]=radius;
            }
            tierNodeCount[tierkeys[i]]=0;
        }
        console.log(tierRadius, tierAngles, perTierNodeCount);

        self.forEachNode(function (node) {
            var nodeAngle = tierAngles[node.tierLevel] * tierNodeCount[node.tierLevel]++;
            var nodeRadians = MathHelper.toRadians(nodeAngle);
            var xpos = 1.2 * tierRadius[node.tierLevel] * Math.cos(nodeRadians);
            var ypos = tierRadius[node.tierLevel] * Math.sin(nodeRadians);
            node._.attr("transform", "translate(" + xpos + "," + ypos + ")");
        });
        self._redrawEdgePathConnection();
        self._drawEdgeGroups();
        self.zoomFit();


        return self;
    };


    /**
     * Applies left right tiered layout
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.layouts["tiered-left-right"] = function () {
        var self = this;

        var SPACING_X = self.config.style.nodeSpacingX;
        var SPACING_Y = self.config.style.nodeSpacingY;

        var tierPositionY = {};
        var actualTierPositionY = {};
        var tierOffsetY = {};
        var widestTier = 0;

        // Calculate positions

        var nodesMap = self.nodes,
            nodeKeys = Object.getOwnPropertyNames(nodesMap);
        for (var i = 0; i < nodeKeys.length; i++) {
            var node = nodesMap[nodeKeys[i]];
            var currentPositionY = tierPositionY[node.tierLevel] || 0,
                newPositionX = currentPositionY += SPACING_Y;
            tierPositionY[node.tierLevel] = newPositionX;
        }

        // Center and position
        var tierYKeys = Object.keys(tierPositionY);
        for(var i = tierYKeys.length; i >= 0; i--) {

            widestTier = tierPositionY[tierYKeys[i]]>widestTier ? tierPositionY[tierYKeys[i]] : widestTier;
        }

        for(var i = tierYKeys.length-1; i >=0; i--) {
            tierOffsetY[tierYKeys[i]] = (widestTier - tierPositionY[tierYKeys[i]]) / 2 ;
        }

        self.forEachNode(function (node) {
            var currentPositionY = actualTierPositionY[node.tierLevel] || 0,
                newPositionY = currentPositionY += SPACING_Y,
                centeredPosition = newPositionY + tierOffsetY[node.tierLevel];
            node._.attr("transform", "translate(" + (node.tierLevel * SPACING_X) + "," + centeredPosition + ")");
            actualTierPositionY[node.tierLevel] = newPositionY;
        });


        self._redrawEdgePathConnection();
        self._drawEdgeGroups();
        self.zoomFit();

        return self;
    };


    /**
     * Applies top-down tiered layout
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.layouts["tiered-top-down"] = function () {
        var self = this;

        var SPACING_X = self.config.style.nodeSpacingX;
        var SPACING_Y = self.config.style.nodeSpacingY;

        var tierPositionX = {};
        var actualTierPositionX = {};
        var tierOffsetX = {};
        var widestTier = 0;

        // Calculate positions

        var nodesMap = self.nodes,
            nodeKeys = Object.getOwnPropertyNames(nodesMap);
        for (var i = 0; i < nodeKeys.length; i++) {
            var node = nodesMap[nodeKeys[i]];
            var currentPositionX = tierPositionX[node.tierLevel] || 0,
                newPositionX = currentPositionX += SPACING_X;
            tierPositionX[node.tierLevel] = newPositionX;
        }

        // Center and position
        var tierXKeys = Object.keys(tierPositionX);
        for(var i = tierXKeys.length; i >= 0; i--) {

            widestTier = tierPositionX[tierXKeys[i]]>widestTier ? tierPositionX[tierXKeys[i]] : widestTier;
        }

        for(var i = tierXKeys.length-1; i >=0; i--) {
            tierOffsetX[tierXKeys[i]] = (widestTier - tierPositionX[tierXKeys[i]]) / 2 ;
        }

        self.forEachNode(function (node) {
            var currentPositionX = actualTierPositionX[node.tierLevel] || 0,
                newPositionX = currentPositionX += SPACING_X,
                centeredPosition = newPositionX + tierOffsetX[node.tierLevel];
            node._.attr("transform", "translate(" + centeredPosition + "," + (node.tierLevel * SPACING_Y) + ")");
            actualTierPositionX[node.tierLevel] = newPositionX;
        });

        self._redrawEdgePathConnection();
        self._drawEdgeGroups();
        self.zoomFit();

        return self;
    };


    /**
     * Applies Tiered Split Rows layout
     * @returns {SevenBridges}
     * @private
     */
    SevenBridges.prototype.layouts["tiered-top-down-split-rows"] = function () {
        var self = this;

        var SPACING_X = self.config.style.nodeSpacingX;
        var SPACING_Y = self.config.style.nodeSpacingY;

        var LEAF_TIER_LEVEL = self.config.style.defaultLeavesTierLevel;

        var tierPositionX = {};
        var tierOffsetX = {};
        var perTierNodeCount = {};
        var perTierNodes = {};
        var widestTier = 0;
        var numAcross = this.config.style.tierSplitNumber;
        var yPosSaved;
        var add125=false;

        // Calculate positions

        var nodesMap = self.nodes,
            nodeKeys = Object.getOwnPropertyNames(nodesMap);
        for (var i = 0; i < nodeKeys.length; i++) {
            var node = nodesMap[nodeKeys[i]];
            var count = perTierNodeCount[node.tierLevel] || 0;
            perTierNodeCount[node.tierLevel] = ++count;
            var currentPositionX = tierPositionX[node.tierLevel] || 0,
                newPositionX = currentPositionX += SPACING_X;
            if(node.tierLevel === LEAF_TIER_LEVEL){
                if(perTierNodeCount[LEAF_TIER_LEVEL] > numAcross){
                    tierPositionX[node.tierLevel] = numAcross*SPACING_X;
                } else {
                    tierPositionX[node.tierLevel] = newPositionX;
                }
            } else {
                tierPositionX[node.tierLevel] = newPositionX;
            }
        }
        var tierkeys = Object.getOwnPropertyNames(perTierNodeCount);

        // Center and position
        var tierXKeys = Object.keys(tierPositionX);
        for(var i = tierXKeys.length; i >= 0; i--) {

            widestTier = tierPositionX[tierXKeys[i]]>widestTier ? tierPositionX[tierXKeys[i]] : widestTier;
        }

        for(var i = tierXKeys.length-1; i >=0; i--) {
            tierOffsetX[tierXKeys[i]] = (widestTier - tierPositionX[tierXKeys[i]]) / 2 ;
        }

        for(var j=0; j<tierkeys.length; j++){
            var tierNodes=[];
            for (var x = 0; x < nodeKeys.length; x++) {
                var n = nodesMap[nodeKeys[x]];
                if(n.tierLevel == tierkeys[j])
                    tierNodes.push(n);
            }
            perTierNodes[tierkeys[j]]=tierNodes;
        }

        var leafNodes = perTierNodes[LEAF_TIER_LEVEL];
        var numSwitches = (!leafNodes ? 0 : leafNodes.length);
        var cnt=0;


        for(var a=0; a<tierkeys.length; a++) {
            var level = tierkeys[a];
            var tierNodes = perTierNodes[level];


            var currentPositionX = 0,
                newPositionX = currentPositionX += SPACING_X,
                centeredPosition = newPositionX + tierOffsetX[level];

            if(level<LEAF_TIER_LEVEL){
                for (var b = 0; b < tierNodes.length; b++) {
                    var nd = tierNodes[b];
                    var xpos = centeredPosition+ (b*SPACING_X);
                    var ypos = (parseInt(level) * SPACING_Y);
                    nd._.attr("transform", "translate(" + xpos + "," + ypos + ")");
                }
                yPosSaved = (parseInt(level) * ypos);
            } else if(level == LEAF_TIER_LEVEL){
                if (numSwitches > numAcross) {
                    //split the leaves tier into rows
                    while (numSwitches > 0) {
                        if (numSwitches > numAcross) {
                            add125 = true;
                            var rowOfNodes = leafNodes.slice(0, numAcross);
                            for (var r = 0; r < rowOfNodes.length; r++) {
                                var nd = rowOfNodes[r];
                                var xpos = centeredPosition + (r*SPACING_X);
                                var ypos = (LEAF_TIER_LEVEL * SPACING_Y) + (cnt*125);
                                nd._.attr("transform", "translate(" + xpos + "," + ypos + ")");
                                yPosSaved = ypos;
                            }
                            cnt++;
                            numSwitches -= numAcross;
                            leafNodes = leafNodes.slice(numAcross, leafNodes.length);
                        } else {
                            add125 = true;
                            for (var b = 0; b < leafNodes.length; b++) {
                                var nd = leafNodes[b];
                                var xpos = centeredPosition + (b*SPACING_X);
                                var ypos = yPosSaved+125;
                                nd._.attr("transform", "translate(" + xpos + "," + ypos + ")");
                            }
                            numSwitches = 0;
                        }

                    }
                }else {
                    if(numSwitches>0){
                        for (var b = 0; b < leafNodes.length; b++) {
                            var nd = leafNodes[b];
                            var xpos = centeredPosition + (b*SPACING_X);
                            var ypos = (LEAF_TIER_LEVEL * SPACING_Y);
                            nd._.attr("transform", "translate(" + xpos + "," + ypos + ")");
                        }
                        yPosSaved = ypos;
                    }

                }
            } else {

                for (var b = 0; b < tierNodes.length; b++) {
                    var nd = tierNodes[b];
                    var xpos = centeredPosition+ (b*SPACING_X);
                    var ypos = yPosSaved + SPACING_Y+ (add125 ? 125 : 0);
                    nd._.attr("transform", "translate(" + xpos + "," + ypos + ")");
                }
                yPosSaved = yPosSaved + SPACING_Y;
            }

        }

        self._redrawEdgePathConnection();
        self._drawEdgeGroups();
        self.zoomFit();

        return self;

    };

    /**
     * Applies left right tiered layout
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.layouts["tiered-left-right-split-rows"] = function () {

        var self = this;

        var SPACING_X = self.config.style.nodeSpacingX;
        var SPACING_Y = self.config.style.nodeSpacingY;

        var LEAF_TIER_LEVEL = self.config.style.defaultLeavesTierLevel;

        var actualTierPositionY = {};
        var tierPositionY = {};
        var tierOffsetY = {};
        var perTierNodeCount = {};
        var perTierNodes = {};
        var widestTier = 0;
        var numAcross = this.config.style.tierSplitNumber;
        var xPosSaved;
        var add125=false;

        // Calculate positions

        var nodesMap = self.nodes,
            nodeKeys = Object.getOwnPropertyNames(nodesMap);
        for (var i = 0; i < nodeKeys.length; i++) {
            var node = nodesMap[nodeKeys[i]];
            var count = perTierNodeCount[node.tierLevel] || 0;
            perTierNodeCount[node.tierLevel] = ++count;
            var currentPositionY = tierPositionY[node.tierLevel] || 0,
                newPositionX = currentPositionY += SPACING_Y;

            if(node.tierLevel === LEAF_TIER_LEVEL){
                if(perTierNodeCount[LEAF_TIER_LEVEL] > numAcross){
                    tierPositionY[node.tierLevel] = numAcross*SPACING_Y;
                } else {
                    tierPositionY[node.tierLevel] = newPositionX;
                }
            } else {
                tierPositionY[node.tierLevel] = newPositionX;
            }
        }
        var tierkeys = Object.getOwnPropertyNames(perTierNodeCount);

        // Center and position
        var tierYKeys = Object.keys(tierPositionY);
        for(var i = tierYKeys.length; i >= 0; i--) {

            widestTier = tierPositionY[tierYKeys[i]]>widestTier ? tierPositionY[tierYKeys[i]] : widestTier;
        }

        for(var i = tierYKeys.length-1; i >=0; i--) {
            tierOffsetY[tierYKeys[i]] = (widestTier - tierPositionY[tierYKeys[i]]) / 2 ;
        }

        for(var j=0; j<tierkeys.length; j++){
            var tierNodes=[];
            for (var x = 0; x < nodeKeys.length; x++) {
                var n = nodesMap[nodeKeys[x]];
                if(n.tierLevel == tierkeys[j])
                    tierNodes.push(n);
            }
            perTierNodes[tierkeys[j]]=tierNodes;
        }

        var leafNodes = perTierNodes[LEAF_TIER_LEVEL];
        var numSwitches = (!leafNodes ? 0 : leafNodes.length);
        var cnt=0;
        var xPosSaved;

        for(var a=0; a<tierkeys.length; a++) {
            var level = tierkeys[a];
            var tierNodes = perTierNodes[level];


            var currentPositionY =  0,
                newPositionY = currentPositionY += SPACING_Y,
                centeredPosition = newPositionY + tierOffsetY[level];

            if(level<LEAF_TIER_LEVEL){
                for (var b = 0; b < tierNodes.length; b++) {
                    var nd = tierNodes[b];
                    var ypos = centeredPosition+ (b*SPACING_Y);
                    var xpos = (parseInt(level) * SPACING_X);
                    nd._.attr("transform", "translate(" + xpos + "," + ypos + ")");
                }
                xPosSaved = (parseInt(level) * xpos);
            } else if(level == LEAF_TIER_LEVEL){
                if (numSwitches > numAcross) {
                    //split the leaves tier into columns
                    while (numSwitches > 0) {
                        if (numSwitches > numAcross) {
                            add125 = true;
                            var rowOfNodes = leafNodes.slice(0, numAcross);
                            for (var r = 0; r < rowOfNodes.length; r++) {
                                var nd = rowOfNodes[r];
                                var ypos = centeredPosition+ (r*SPACING_Y);
                                var xpos = (LEAF_TIER_LEVEL * SPACING_X) + (cnt*125);
                                nd._.attr("transform", "translate(" + xpos + "," + ypos + ")");
                                xPosSaved = xpos;
                            }
                            cnt++;
                            numSwitches -= numAcross;
                            leafNodes = leafNodes.slice(numAcross, leafNodes.length);
                        } else {
                            add125 = true;
                            for (var b = 0; b < leafNodes.length; b++) {
                                var nd = leafNodes[b];
                                var ypos = centeredPosition + (b*SPACING_X);
                                var xpos = xPosSaved+125;
                                nd._.attr("transform", "translate(" + xpos + "," + ypos + ")");
                            }
                            numSwitches = 0;
                        }

                    }
                }else {
                    if(numSwitches>0) {
                        for (var b = 0; b < leafNodes.length; b++) {
                            var nd = leafNodes[b];
                            var ypos = centeredPosition + (b * SPACING_Y);
                            var xpos = (LEAF_TIER_LEVEL * SPACING_X);
                            nd._.attr("transform", "translate(" + xpos + "," + ypos + ")");
                        }
                        xPosSaved = xpos;
                    }
                }
            }else {

                for (var b = 0; b < tierNodes.length; b++) {
                    var nd = tierNodes[b];
                    var ypos = centeredPosition+ (b*SPACING_Y);
                    var xpos = xPosSaved + SPACING_X+ (add125 ? 125 : 0);
                    nd._.attr("transform", "translate(" + xpos + "," + ypos + ")");
                }
                xPosSaved = xPosSaved + SPACING_X;
            }

        }

        self._redrawEdgePathConnection();
        self._drawEdgeGroups();
        self.zoomFit();
        return self;
    };

    /**
     * Applies a force-directed layout
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.layouts["force-directed"] = function () {
        var self = this;
        var bbox = self._root.node().getBoundingClientRect();
        var width = bbox.width;
        var height = bbox.height;


        // Build the initial node list
        var nodes = [];
        self.forEachNode(function (node, i, length) {
            nodes.push({
                _: node,
                x: 0,
                y: 0
            });
        });

        // Fetches the index of the node
        function getIndexOfNodeId(id) {
            for (var i = 0; i < nodes.length; i++) {
                if (nodes[i]._.id == id) {
                    return i;
                }
            }
            return 0;
        }

        var links = [];
        self.forEachEdge(function (edge) {
            links.push({
                source: getIndexOfNodeId(edge.srcNode.id),
                target: getIndexOfNodeId(edge.destNode.id)
            });
        });

        var node = self._root.selectAll(".sb-node").data(nodes);

        function tick(skipPathReDraw) {
            node.attr('transform', function (d) {
                return 'translate(' + (d.x || 0) + ',' + (d.y || 0) + ')';
            });

            if (!skipPathReDraw) {
                self._redrawEdgePathConnection();
            }
        }

        function start() {
            var ticksPerRender = 20;
            requestAnimationFrame(function render() {
                for (var i = 0; i < ticksPerRender; i++) {
                    force.tick(true);
                }
                tick();

                if (force.alpha() > 0) {
                    requestAnimationFrame(render);
                }
            })
        }

        var force = d3.layout.force()
            .size([width, height])
            .nodes(nodes)
            .charge(-5000)
            .linkDistance(400)
            .links(links)
            .on('start', start)
            .on("tick", tick);

        force.on('end', function() {
            self._drawEdgeGroups();
            self.zoomFit();
        });

        self.zoomByFactor(0);

        force.start();

        return self;
    };

    /**
     * Applies a custom saved layout that is stored in the string
     * layouts["custom-saved-layout"].customLayoutString
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.layouts["custom-saved-layout"] = function () {
        var self = this;
        var layoutString = self.layouts["custom-saved-layout"].customLayoutString;
        self.applySavedLayout(layoutString);
        return self;
    };


    /**
     * The custom layout string
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.layouts["custom-saved-layout"].customLayoutString = null;


    /**
     *
     * @param {string} layoutString
     */
    SevenBridges.prototype.applySavedLayout = function (layoutString) {
        var self = this;
        var width = 0;
        var height = 0;

        var layoutPositions = JSON.parse(layoutString);

        if (!layoutPositions.size) {
            var bbox = self._root.node().getBoundingClientRect();
            width = bbox.width;
            height = bbox.height;
        } else {
            width = layoutPositions.size[0];
            height = layoutPositions.size[1];
        }

        self._root.attr('transform', layoutPositions.root);

        var nn = self._root.selectAll(".sb-node");

        // Build the initial node list
        var nodes = [];
        Utils.forEach(nn[0], function (n) {
            n = d3.select(n);
            var id = n.attr('data-sb-node-id');
            var node = self.fetchNodeById(id);
            var translation = layoutPositions.nodes[node.id];
            if (translation) {
                nodes.push({
                    _: node,
                    x: translation[0],
                    y: translation[1],
                    fixed: true
                });
            } else {
                nodes.push({
                    _: node,
                    x: 0,
                    y: 0
                });
            }
        });

        // Fetches the index of the node
        function getIndexOfNodeId(id) {
            for (var i = 0; i < nodes.length; i++) {
                if (nodes[i]._.id == id) {
                    return i;
                }
            }
            return 0;
        }

        var links = [];
        self.forEachEdge(function (edge) {
            links.push({
                source: getIndexOfNodeId(edge.srcNode.id),
                target: getIndexOfNodeId(edge.destNode.id)
            });
        });

        var node = nn.data(nodes);

        function tick(skipPathReDraw) {
            node.attr('transform', function (d) {
                return 'translate(' + (d.x || 0) + ',' + (d.y || 0) + ')';
            });

            if (!skipPathReDraw) {
                self._redrawEdgePathConnection();
            }
        }

        function start() {
            var ticksPerRender = 20;
            requestAnimationFrame(function render() {
                for (var i = 0; i < ticksPerRender; i++) {
                    force.tick(true);
                }
                tick();

                if (force.alpha() > 0) {
                    requestAnimationFrame(render);
                }
            })
        }

        var force = d3.layout.force()
            .size([width, height])
            .nodes(nodes)
            .charge(-5000)
            .linkDistance(400)
            .links(links)
            .on('start', start)
            .on("tick", tick);

        force.on('end', function() {
            self._drawEdgeGroups();
            self.zoomFit();
        });

        //self.zoomByFactor(0);

        force.start();

        return self;
    };


    /**
     * Get the save layout string
     * @returns {string} Save string
     */
    SevenBridges.prototype.getSaveLayoutString = function () {
        var self = this;
        var items = {
            nodes: {},
            size: null,
            root: null
        };

        self.forEachNode(function (node) {
            var translation = d3.transform(node._.attr('transform')).translate;
            items.nodes[node.id] = translation;
        });

        items.root = d3.transform(self._root.attr('transform')).toString();

        var bbox = this._root.node().getBoundingClientRect();
        var width = bbox.width;
        var height = bbox.height;
        items.size = [width, height];

        return JSON.stringify(items);
    };


    //</editor-fold>


    //<editor-fold desc="Node rendering">

    /**
     * Gets the path of the icon for node rendering
     * @param {Node} node
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._getNodeImagePath = function (node) {
        var icon = node.displayIcon || "";

        // If no icon is specified, choose the default icon
        if (Utils.strIsNullOrWhiteSpace(icon)) {
            icon = this.config.style.defaultNodeIcon;
        }

        // Try to see if the user supplied file extension. If not
        // then assume '.svg' extension
        if (icon.substr(icon.lastIndexOf('.') + 1) == icon) {
            icon = icon + ".svg";
        }
        return retrieveFullQualifiedUrl(this.config.iconsRelativePath + icon);
    };


    /**
     * Individual node renderer
     * @param {Node} node
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._renderNode = function (node) {
        var self = this,
            NODE_MAX_WIDTH = 200,
            NODE_IMAGE = 35,
            NODE_CIRCLE_WIDTH = 70,
            NODE_TEXT_PADDING = 8,
            NODE_TEXT_TOTAL_WIDTH = NODE_MAX_WIDTH - (2 * NODE_TEXT_PADDING),
            NODE_BADGE_PADDING = 2,
            NODE_BADGE_TOP_MARGIN = 24;

        var g = node._ || self._root.append('svg:g');




        // Identifier
        g.attr('data-sb-node-id', node.id);

        // Add the appropriate CSS classes
        g.classed(node.cssClass, true).classed('sb-node', true);

        if(node.shouldRenderFabCloud){
            g.append('svg:circle')
                .attr('class', 'sb-node-display-icon-bg')
                .attr('r', 0);
                //.attr('style', 'cx:-75px;');

            g.append('svg:image')
                .attr('class', 'sb-node-display-icon')
                .attr('xlink:href', self._getNodeImagePath(node))
                .attr('width', 200)
                .attr('height', 200)
                .attr('x', -100)
                .attr('y', -100);

            textLine1 = g.append('svg:text')
                .attr('class', 'sb-node-display-text')
                .attr('text-anchor', 'middle')
                .attr('style', 'font-size: 20px;')
                .attr('y', 0)
                .attr('x', 0);
        }else{
            // Add circle
            g.append('svg:circle')
                .attr('class', 'sb-node-display-icon-bg')
                .attr('r', NODE_CIRCLE_WIDTH/2);

            // Add the icon
            g.append('svg:image')
                .attr('class', 'sb-node-display-icon')
                .attr('xlink:href', self._getNodeImagePath(node))
                .attr('width', NODE_IMAGE)
                .attr('height', NODE_IMAGE)
                .attr('x', -NODE_CIRCLE_WIDTH/4)
                .attr('y', -NODE_CIRCLE_WIDTH/4);

            // Add the text
            var textLine1 = g.append('svg:text')
                .attr('class', 'sb-node-display-text')
                .attr('text-anchor', 'middle')
                .attr('y', NODE_CIRCLE_WIDTH);
        }



        // Set the text. If it overflows, then append
        // ellipses in the middle
        var textToDisplay = node.displayName || "";
        textLine1.text(function () { return textToDisplay; });
        if (textLine1 && textLine1.node() && textLine1.node().getBBox().width > NODE_TEXT_TOTAL_WIDTH && this.config.trimNodeText) {
            while (textLine1.node().getBoundingClientRect().width > NODE_TEXT_TOTAL_WIDTH) {
                textToDisplay = Utils.strRemoveMiddleCharacter(textToDisplay);
                textLine1.text(function () { return textToDisplay + "..."; });
            }
            textLine1.text(function () { return Utils.strInsertEllipsisInMiddle(textToDisplay); });
        }

        // Append Border / Host badges
        if(!Utils.strIsNullOrWhiteSpace(node.badge)) {
            // Add the Rectangle
            var rect = g.append('svg:rect')
                .attr('x', 0)
                .attr('y', NODE_BADGE_TOP_MARGIN)
                .attr('rx', 1)
                .attr('ry', 1)
                .attr('fill', '#ea5b5b');

            // Add the Text SVG
            var textSvg = g.append('svg:svg')
                .attr('y', NODE_BADGE_TOP_MARGIN);

            // Add the Text
            var textLine2 = textSvg.append('svg:text')
                .attr('class', 'sb-node-pmn-badge-label')
                .attr('y', '50%')
                .attr('x', '50%')
                .attr('alignment-baseline', 'middle')
                .attr('text-anchor', 'middle')
                .text(function () { return node.badge; });

            var NODE_BADGE_WIDTH = textLine2.node().getBBox().width + (2 * NODE_BADGE_PADDING);
            var NODE_BADGE_HEIGHT = textLine2.node().getBBox().height + (2 * NODE_BADGE_PADDING);

            rect.attr('width', NODE_BADGE_WIDTH)
                .attr('height', NODE_BADGE_HEIGHT);
            textSvg.attr('width', NODE_BADGE_WIDTH)
                .attr('height', NODE_BADGE_HEIGHT);

        }



        // Set the group's underlying render library's
        // object to the current object. We keep a reference
        // to the object for quick access
        node._ = g;

        return self;
    };


    /**
     * Draw all the nodes
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._drawNodes = function () {
        var self = this;

        // Draw all the nodes
        self.forEachNode(function (node) {
            self._renderNode(node);
        });

        return self;
    };


    /**
     * Draws the node groups
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._drawNodeGroups = function () {
        var self = this;

        // Create a group for each nodeGroup and move
        // all the associated nodes inside of it
        self.forEachNodeGroup(function(nodeGroup) {
            // Create a group
            nodeGroup._ = self._root.append('svg:g')
                .classed('sb-node-group', true)
                .attr('data-sb-node-group-id', nodeGroup.id);

            // Move all the nodes to the current group
            Utils.forEach(nodeGroup.nodes, function (node) {
                nodeGroup._.node().appendChild(node._.node());
            });
        });

        return self;
    };

    //</editor-fold>


    //<editor-fold desc="Edge rendering">

    /**
     * Computes the path between two points
     * @param {Point} point1 Coordinates for point 1
     * @param {Point} point2 Coordinates for point 2
     * @param {number} multiLinkIndex
     * @param {number} multiLinkTotalCount
     * @returns {String}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._computePathConnectionString = function (point1, point2, multiLinkIndex, multiLinkTotalCount) {
        var self = this;

        /**
         * Computes the new (x,y)
         * @param {Point} point1
         * @param {Point} point2
         * @param {number} multiLinkIndex
         * @param {number} multiLinkTotalCount
         * @returns {{cx1: (number), cy1: (number), cx2: (number), cy2: (number), dx: (number), dy: (number)}}
         */
        function computeMultiLinkDeltaAndPosition(point1, point2, multiLinkIndex, multiLinkTotalCount) {
            var EDGE_SPACING = self.config.style.multiLinkEdgeSpacing,
                o1CenterX = point1.x,
                o1CenterY = point1.y,
                o2CenterX = point2.x,
                o2CenterY = point2.y,
                spacingDeltaX = 0,
                spacingDeltaY = 0;

            // If the total number of edges to draw is greater than 1,
            // then compute the position based on its index
            if (multiLinkTotalCount > 1) {

                var slope = (o2CenterY - o1CenterY)/(o1CenterX - o2CenterX), // Slope between box1 and box2
                    theta = Math.atan(isNaN(slope) ? 0 : slope),   // The angle between dy and dx
                    countMidPoint, i, indexedOffset, hypotenuseLength;

                // Even-odd case
                if (Utils.isEven(multiLinkTotalCount)) {
                    countMidPoint = multiLinkTotalCount / 2;
                    i = multiLinkIndex + 1;
                    indexedOffset = 0;
                    hypotenuseLength = 0;

                    if (i <= countMidPoint) {
                        indexedOffset = -(countMidPoint - i + 1);
                        hypotenuseLength = indexedOffset * EDGE_SPACING + EDGE_SPACING / 2;
                    } else {
                        indexedOffset = i - countMidPoint;
                        hypotenuseLength = indexedOffset * EDGE_SPACING - EDGE_SPACING / 2;
                    }

                    spacingDeltaX = hypotenuseLength * Math.sin(theta);
                    spacingDeltaY = hypotenuseLength * Math.cos(theta);
                } else {
                    countMidPoint = Math.ceil(multiLinkTotalCount/2) + 1;
                    i = multiLinkIndex + 1;
                    indexedOffset = 0;
                    hypotenuseLength = 0;

                    if (i === countMidPoint) {
                        indexedOffset = 0;
                        hypotenuseLength = 0;
                    } else if (i < countMidPoint) {
                        indexedOffset = -(countMidPoint - i + 1);
                        hypotenuseLength = indexedOffset * EDGE_SPACING + EDGE_SPACING;
                    } else {
                        indexedOffset = i - countMidPoint + 1;
                        hypotenuseLength = indexedOffset * EDGE_SPACING - EDGE_SPACING;
                    }

                    spacingDeltaX = hypotenuseLength * Math.sin(theta);
                    spacingDeltaY = hypotenuseLength * Math.cos(theta);
                }

                o1CenterX += spacingDeltaX;
                o1CenterY += spacingDeltaY;
                o2CenterX += spacingDeltaX;
                o2CenterY += spacingDeltaY;
            }

            return {
                cx1: o1CenterX,
                cy1: o1CenterY,
                cx2: o2CenterX,
                cy2: o2CenterY,
                spacingDx: spacingDeltaX,
                spacingDy: spacingDeltaY
            };
        }

        /**
         * Returns a straight line path
         * @param {Point} point1
         * @param {Point} point2
         * @param {number} multiLinkIndex
         * @param {number} multiLinkTotalCount
         * @returns {string}
         */
        function straightLine(point1, point2, multiLinkIndex, multiLinkTotalCount) {
            var multiLinkDeltaAndPosition = computeMultiLinkDeltaAndPosition(point1, point2, multiLinkIndex, multiLinkTotalCount),
                o1x = multiLinkDeltaAndPosition.cx1,
                o1y = multiLinkDeltaAndPosition.cy1,
                o2x = multiLinkDeltaAndPosition.cx2,
                o2y = multiLinkDeltaAndPosition.cy2;
            return "M" + o1x + "," + o1y + "L" + o2x + "," + o2y;
        }

        /**
         * Returns a curved path
         * @param {Point} point1
         * @param {Point} point2
         * @param {number} multiLinkIndex
         * @param {number} multiLinkTotalCount
         * @returns {string}
         */
        function curvedLine(point1, point2, multiLinkIndex, multiLinkTotalCount) {

            // INFO: If you want to swap the diagonals: http://stackoverflow.com/a/23446203
            var diagonal = d3.svg.diagonal()
                .source(function(d) { return {"x":d.source.x, "y":d.source.y}; })
                .target(function(d) { return {"x":d.target.x, "y":d.target.y}; })
                .projection(function(d) { return [d.x, d.y]; });

            var multiLinkDeltaAndPosition = computeMultiLinkDeltaAndPosition(point1, point2, multiLinkIndex, multiLinkTotalCount);

            return diagonal({
                source: { x: multiLinkDeltaAndPosition.cx1, y: multiLinkDeltaAndPosition.cy1 },
                target: { x: multiLinkDeltaAndPosition.cx2, y: multiLinkDeltaAndPosition.cy2 }
            });
        }

        // Return the path string
        if (this.config.style.edgeConnectionType == 'straight') {
            return straightLine(point1, point2, multiLinkIndex, multiLinkTotalCount);
        } else {
            return curvedLine(point1, point2, multiLinkIndex, multiLinkTotalCount);
        }
    };


    /**
     * Draws the actual path between two nodes
     * @param {Edge} edge
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._drawPathConnection = function (edge) {
        var self = this,
            t1 = d3.transform(edge.srcNode._.attr('transform')),
            t2 = d3.transform(edge.destNode._.attr('transform')),
            point1 = { x: t1.translate[0], y: t1.translate[1] },
            point2 = { x: t2.translate[0], y: t2.translate[1] },
            path = self._computePathConnectionString(point1, point2, edge.multiLinkPositionIndex, edge.multiLinkTotalLinkCount);


        /**
         * Update the text position so that it is centered and faces up
         */
        function updateTextPosition() {
            if (edge._text && edge.text && edge.text != '') {

                var edgeNode = edge._.node();
                var textNode= edge._text.node();
                var midpoint = (edgeNode.getTotalLength()/2) - (textNode.getComputedTextLength()/2);

                edge._text.attr("x", midpoint)
                    .attr("dy", 15);

                // Should the text be flipped so it's not upside down
                if ((point1.y < point2.y && point1.x >= point2.x) || (point1.y >= point2.y && point1.x >= point2.x)) {
                    var bBox = textNode.getBBox();
                    if (bBox.x == 0 && bBox.y == 0 && bBox.width == 0 && bBox.height == 0) {
                        edge._text.attr("transform", '');
                    } else {
                        var rotatecenterX = (bBox.x + bBox.width / 2);
                        var rotatecenterY = (bBox.y + bBox.height / 2);
                        edge._text.attr('transform', 'rotate(180 ' + rotatecenterX + ' ' + rotatecenterY + ')');
                    }
                } else {
                    edge._text.attr("transform", '');
                }
            }
        }

        // Draw the path object if it has not yet been drawn
        if (!edge._) {
            var id = "path_" + self.id + "_" + edge.id;

            edge._ = self._root.append('svg:path')
                .attr('id', id)
                .attr('class', 'sb-edge')
                .classed(edge.cssClass, true)
                .attr('data-sb-edge-id', edge.id)
                .moveToBack();

            if (edge.text && edge.text != '') {

                var createTextElement = function() {
                    // Append the text element
                    edge._text = self._root.append("text")
                        .attr('class', 'sb-edge-text')
                        .attr("x", 0)
                        .attr("dy", 15).moveToBack();

                    // Bind the text element to the curve
                    edge._textPath = edge._text.append("textPath");

                    edge._textPath.attr("xlink:href", "#" + id).html(edge.text);
                };

                createTextElement();

                var originalSetText = edge.setText;
                edge.setText = function (text) {
                    originalSetText(text);

                    if (text && text != '') {
                        if (!edge._text) {
                            createTextElement();
                        }
                        var edgeNode = edge._.node();
                        var textNode = edge._text.node();
                        var midpoint = (edgeNode.getTotalLength() / 2) - (textNode.getComputedTextLength() / 2);

                        edge._textPath.text(edge.text);
                        edge._text.attr("x", midpoint)
                            .attr("dy", 15).attr('transform', '');

                        updateTextPosition();
                    } else {
                        if (edge._text) {
                            edge._text.node().remove();
                            delete edge._text;
                        }
                    }
                };
            }
        }

        updateTextPosition();

        // Set the new path
        edge._.attr('d', path);

        return self;
    };


    /**
     * Draw all the edges
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._drawEdges = function () {
        var self = this;
        self.forEachEdge(function (edge) {
            if (!edge.flags.hasBeenDrawn) {
                self._drawPathConnection(edge);
                edge.flags.hasBeenDrawn = true;
            }
        });
        return self;
    };


    /**
     * Utility method for reconnecting the edge path connections
     * once they've been drawn
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._redrawEdgePathConnection = function () {
        var self = this;
        self.forEachEdge(function (edge) {
            self._drawPathConnection(edge);
        });
        return self;
    };

    /**
     * Draw the edge groups
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._drawEdgeGroups = function () {
        var self = this;
        self.forEachEdgeGroup(function(edgeGroup) {
            // Create a group
            if (!edgeGroup._) {
                edgeGroup._ = self._root.append('g')
                    .classed('sb-edge-group', true)
                    .attr('data-sb-edge-group-id', edgeGroup.id)
                    .moveToBack();
            }
            if (!edgeGroup._.ellipse) {
                edgeGroup._.ellipse= edgeGroup._.append("svg:ellipse")
                    .classed('sb-portchannel', true)
                    .classed(edgeGroup.cssClass, true);
            }

            // Move all the edges to the current group
            Utils.forEach(edgeGroup.edges, function (edge) {
                edgeGroup._.node().appendChild(edge._.node());
            });
        });

        // Perform draw action based on set rules
        // draw port channel
        self.forEachEdgeGroup(function(edgeGroup) {
            // Create a group
            if (edgeGroup.isPortChannel) {
                self._drawPortChannel(edgeGroup);
            }else {
                self._drawVPC(edgeGroup);
            }
        });

        return self;
    };

    /**
     * Draw VPC
     * @param {EdgeGroup} edgeGroup
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._drawVPC = function (edgeGroup) {
        var self = this;
        var numEdges = edgeGroup.edges.length;
        if(numEdges == 0) return self;
        var edge1 = edgeGroup.edges[0],
            edge2 = edgeGroup.edges[numEdges-1],
            edge1DomNode = edge1._.node(),
            edge1Length = edge1DomNode.getTotalLength(),
            point1 = edge1DomNode.getPointAtLength(edge1Length / 2),
            yrad = 2,
            one_third_points_center=point1,
            perp_slope = 0;
        if (edge2 == null) {
            yrad = 10;
        } else {
            var edge2DomNode = edge2._.node(),
                edge1Length = edge1DomNode.getTotalLength(),
                edge2Length = edge2DomNode.getTotalLength(),
                point0 = edge1DomNode.getPointAtLength(0),
                point1 = edge2DomNode.getPointAtLength(0),
                point2 = edge1DomNode.getPointAtLength(edge1Length),
                point3 = edge2DomNode.getPointAtLength(edge2Length);
            var startpoint, endpoint1, endpoint2, endpoints_center, one_third_point1, one_third_point2,smallerlength;
            var radius = 0;
            if(edge1Length>edge2Length){
                smallerlength=edge2Length;
            }else{
                smallerlength=edge1Length;
            }
            if (edge1.srcNode == edge2.srcNode) {
                // Case src node common
                startpoint = point0;
                endpoints_center = MathHelper.midpoint(point2, point3);
                endpoint1 = point2;
                endpoint2 = point3;
                one_third_point1 = edge1DomNode.getPointAtLength(smallerlength / 3);
                one_third_point2 = edge2DomNode.getPointAtLength(smallerlength / 3);
                one_third_points_center = MathHelper.midpoint(one_third_point1, one_third_point2);
            } else if (edge1.srcNode == edge2.destNode) {
                // Case src node to dest node
                startpoint = point0;
                endpoints_center = MathHelper.midpoint(point1, point2);
                endpoint1 = point1;
                endpoint2 = point2;
                one_third_point1 = edge1DomNode.getPointAtLength(smallerlength / 3);
                one_third_point2 = edge2DomNode.getPointAtLength(edge2Length-(smallerlength / 3));
                one_third_points_center = MathHelper.midpoint(one_third_point1, one_third_point2);
            } else if (edge1.destNode == edge2.srcNode) {
                // Case dest node to src node
                startpoint = point2;
                endpoints_center = MathHelper.midpoint(point0, point3);
                endpoint1 = point0;
                endpoint2 = point3;
                one_third_point1 = edge1DomNode.getPointAtLength(edge1Length-(smallerlength / 3));
                one_third_point2 = edge2DomNode.getPointAtLength(smallerlength / 3);
                one_third_points_center = MathHelper.midpoint(one_third_point1, one_third_point2);
            } else if (edge1.destNode == edge2.destNode) {
                // Case dest node common
                startpoint = point2;
                endpoints_center = MathHelper.midpoint(point0, point1);
                endpoint1 = point0;
                endpoint2 = point1;
                one_third_point1 = edge1DomNode.getPointAtLength(edge1Length-(smallerlength / 3));
                one_third_point2 = edge2DomNode.getPointAtLength(edge2Length-(smallerlength / 3));
                one_third_points_center = MathHelper.midpoint(one_third_point1, one_third_point2);
            } else{
                return self;
            }

            var center_riserun = 1;

            if (Math.abs(startpoint.y - endpoints_center.y) > 1 && Math.abs(startpoint.x - endpoints_center.x) > 1) {
                center_riserun = (startpoint.y - endpoints_center.y) / (startpoint.x - endpoints_center.x);
                perp_slope = -Math.atan(1 / center_riserun) * 180 / Math.PI; // perpendicular Slope between edges
                radius = Math.sqrt(Math.pow((one_third_point2.x - one_third_points_center.x), 2) + Math.pow((one_third_point2.y - one_third_points_center.y), 2));
            } else {
                if (Math.abs(startpoint.y - endpoints_center.y) <= 1) {
                    perp_slope = 90;
                    radius = Math.abs(one_third_point1.y - one_third_points_center.y);
                } else {
                    perp_slope = 0;
                    radius = Math.abs(one_third_point1.x - one_third_points_center.x);
                }
            }
        }
        if (!edgeGroup._) {
            edgeGroup._ = self._root.append("svg:ellipse")
                .classed('sb-portchannel', true)
                .classed(edgeGroup.cssClass, true)
            //   .moveToBack();
        }
//FIX THIS and comment back in
        edgeGroup._.ellipse.attr("cx", one_third_points_center.x)
            .attr("cy", one_third_points_center.y)
            .attr("rx", Utils.isNumeric(radius) ? radius + 20 : 10)
            .attr("ry", 10)
            .attr("transform", "rotate(" + (perp_slope) + "," + one_third_points_center.x + "," + one_third_points_center.y + ")");



        //    theta = Math.atan(isNaN(slope) ? 0 : slope);
        return self;
    };


    /**
     *
     * @param {EdgeGroup} edgeGroup
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._drawPortChannel = function (edgeGroup) {
        var self = this;

        if (edgeGroup.edges.length == 0) return self;

        var edge1 = edgeGroup.edges[0],
            edge1DomNode = edge1._.node(),
            edge1Length = edge1DomNode.getTotalLength(),
            point1 = edge1DomNode.getPointAtLength(edge1Length / 2),
            one_third_points_center = point1,
            coords1,
            coords2,
            angleRadians,
            angleDegrees = 0,
            radius = 0,
            yrad = 10,
            edge1HostType = edge1.destNode.data.external;

        if (edgeGroup.edges.length > 1) {
            var edge2 = edgeGroup.edges[edgeGroup.edges.length-1],
                edge2DomNode = edge2._.node(),
                edge2Length = edge2DomNode.getTotalLength(),
                edge1Length = edge1DomNode.getTotalLength(),
                point0 = edge1DomNode.getPointAtLength(0),
                point1 = edge2DomNode.getPointAtLength(0),
                point2 = edge1DomNode.getPointAtLength(edge1Length),
                edge2HostType = edge2.destNode.data.external;
            var startpoint, endpoints_center, one_third_point1, one_third_point2, smallerlength;
			if(edgeGroup.cssClass == "vpclink") {
				var midpointEdge1 = one_third_points_center,
				midpointEdge2 = edge2DomNode.getPointAtLength(edge2Length / 2);
				
				coords1 = self._getResolvedCoordinates(midpointEdge1.x,midpointEdge1.y);
				coords2 = self._getResolvedCoordinates(midpointEdge2.x,midpointEdge2.y);
				radius = MathHelper.euclideanDistance(coords1.x, coords1.y,coords2.x, coords2.y) / 2 + 8;
				yrad = 5;
				
				angleRadians = MathHelper.angleBetweenPoints(coords1, coords2);
				angleDegrees = MathHelper.toDegrees(angleRadians);				
				one_third_points_center = MathHelper.midpoint(coords1, coords2);                
            } else {
				if(edge1Length > edge2Length){
					smallerlength = edge2Length;
				} else {
					smallerlength = edge1Length;
				}

				if (edge1.destNode == edge2.destNode) {
					startpoint = point2;
					endpoints_center = MathHelper.midpoint(point0, point1);
					one_third_point1 = edge1DomNode.getPointAtLength(edge1Length-(smallerlength / 3));
					one_third_point2 = edge2DomNode.getPointAtLength(edge2Length-(smallerlength / 3));
					one_third_points_center = MathHelper.midpoint(one_third_point1, one_third_point2);
				} else {
					return self;
				}

				var center_riserun = 1;
				if (Math.abs(startpoint.y - endpoints_center.y) > 1 && Math.abs(startpoint.x - endpoints_center.x) > 1) {
					center_riserun = (startpoint.y - endpoints_center.y) / (startpoint.x - endpoints_center.x);
					angleDegrees = -Math.atan(1 / center_riserun) * 180 / Math.PI; // perpendicular Slope between edges
					radius = Math.sqrt(Math.pow((one_third_point2.x - one_third_points_center.x), 2) + Math.pow((one_third_point2.y - one_third_points_center.y), 2));
				} else {
					if (Math.abs(startpoint.y - endpoints_center.y) <= 1) {
						angleDegrees = 90;
						radius = Math.abs(one_third_point1.y - one_third_points_center.y);
					} else {
						angleDegrees = 0;
						radius = Math.abs(one_third_point1.x - one_third_points_center.x);
					}
				}
				radius += 20;

				if(edge1HostType === true || edge2HostType === true) {
					edgeGroup._.ellipse.classed('sb-remoteportchannel', true);
				} else if(edge1HostType === false && edge2HostType === false){
					edgeGroup._.ellipse.classed('sb-localportchannel', true);
				}
			}
        }
        else if (edgeGroup.edges.length == 1) {
            coords1 = edge1DomNode.getPointAtLength(0);
            coords2 = edge1DomNode.getPointAtLength(edge1Length);
            one_third_points_center = edge1DomNode.getPointAtLength(edge1Length / 2),
                radius = 4;
            angleRadians = MathHelper.angleBetweenPoints(coords1, coords2);
            angleDegrees = MathHelper.toDegrees(angleRadians);
        }

        if (!edgeGroup._) {
            edgeGroup._ = self._root.append("svg:ellipse")
                .classed('sb-portchannel', true)
                .classed(edgeGroup.cssClass, true);
        }

        edgeGroup._.ellipse.attr("cx", one_third_points_center.x)
            .attr("cy", one_third_points_center.y)
            .attr("rx", Utils.isNumeric(radius) ? radius : 10)
            .attr("ry", yrad)
            .attr("transform", "rotate(" + (angleDegrees) + "," + one_third_points_center.x + "," + one_third_points_center.y + ")");


        return self;
    };

    //</editor-fold>


    //<editor-fold desc="Node dragging">

    /*var startingOrigin = null;
     var currentOrigin = null;
     var timeoutId = null;
     var isInDrag = false;
     var startingTime = 0;
     var counter = 0;*/


    SevenBridges.prototype._isSyntheticClickWithinTimeLimits = function () {
        return Math.abs(this._dragStartingTime - Date.now()) < 500;
    };


    SevenBridges.prototype._dragSyntheticClickTimer = function (that, d3Element) {
        var self = that;

        // If is in drag or not within the timeout limits
        // or if not a double-click, return
        if (self.flagIsInSelectionMode || self._isInDrag || !this._isSyntheticClickWithinTimeLimits() || self._dragClickCounter < 2) {
            return;
        }

        var startingOrigin = self._dragStartingOrigin;
        var currentOrigin = self._dragCurrentOrigin;
        var originScreenX  = startingOrigin ? startingOrigin.screenX : currentOrigin.screenX;
        var originScreenY  = startingOrigin ? startingOrigin.screenY : currentOrigin.screenY;
        var currentScreenX = currentOrigin.screenX;
        var currentScreenY = currentOrigin.screenY;

        if (originScreenX == currentScreenX && originScreenY == currentScreenY) {
            var node = self.fetchNodeById(d3Element.attr('data-sb-node-id'));
            self._on("node", "dblclick", node, self);
            self._on("node", "click", node, self);
        }
        return self;
    };


    /**
     * Called when dragging first starts
     * @param that Context of caller
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._onNodeDragStart = function (that) {
        var self = this,
            d3Element = d3.select(that);

        Log.info('Dragging START | _onNodeDragStart()', d3Element);

        // Start keeping track of the first time a user
        // clicks in order to trigger a synthetic click
        // in the future. This is to address
        // the Chromium bug 716694
        if (!self._isSyntheticClickWithinTimeLimits()) {
            self._dragClickCounter = 0;
        }

        // Keep track of local variables
        self._isInDrag = false;
        self._dragClickCounter += 1;
        self._dragStartingTime = Date.now();
        self._dragStartingOrigin = d3.event.sourceEvent;
        self._dragCurrentOrigin = self._dragStartingOrigin;

        // clear any existing timers
        if (self._dragTimeoutId) {
            clearTimeout(self._dragTimeoutId);
        }
        self._dragTimeoutId = setTimeout(function () {
            self._dragSyntheticClickTimer(self, d3Element);
        }, 50);


        // Indicate the node is beginning to drag
        self.flagIsInNodeDrag = true;

        // As far as I've observed, the underlying zoom event consumes the mouse event.
        // Thus there are problems when we go to zoom in at a particular point
        // See reference note about why we stop event propagation: http://bl.ocks.org/robschmuecker/7880033
        // See also: https://github.com/mbostock/d3/wiki/Drag-Behavior#on
        d3.event.sourceEvent.stopPropagation();
        d3.event.sourceEvent.preventDefault();

        // Bring node to the front
        d3Element.moveToFront().classed('sb-event-drag-active', true);

        // Apply appropriate classes
        self._.classed('sb-event-drag', true);
        self._.classed('sb-event-drag-start', true);
        self._.classed('sb-event-drag-end', false);

        // edges
        var sourceNode = self.fetchNodeById(d3Element.attr('data-sb-node-id'));
        if (sourceNode != null) {
            Utils.forEach(sourceNode.edges, function (edge) {
                edge._.classed('sb-event-drag-active', true);
                edge.srcNode._.classed('sb-event-drag-active', true);
                edge.destNode._.classed('sb-event-drag-active', true);
                self._moveRightBehindFirstNodeOrNodeGroup(edge._.node());
                if (edge._text) {
                    edge._text.classed('sb-event-drag-active', true);
                    self._moveRightBehindFirstNodeOrNodeGroup(edge._text.node());
                }
            });
        } else {
            var groupElement = self.fetchNodeGroupById(d3Element.attr('data-sb-node-group-id'));
            Utils.forEach(groupElement.nodes, function (node) {
                Utils.forEach(node.edges, function (edge) {
                    edge._.classed('sb-event-drag-active', true);
                    self._moveRightBehindFirstNodeOrNodeGroup(edge._.node());
                    if (edge._text) {
                        edge._text.classed('sb-event-drag-active', true);
                        self._moveRightBehindFirstNodeOrNodeGroup(edge._text.node());
                    }
                });
            });
        }

        return self;
    };

    /**
     * Called when dragging stops
     * @param that Context of caller
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._onNodeDragEnd = function (that) {
        var self = this;

        Log.info('Dragging STOP | _onNodeDragEnd()', that);

        if (!self._isSyntheticClickWithinTimeLimits()) {
            self._dragClickCounter = 0;
        }
        self._dragStartingOrigin = null;

        // As far as I've observed, the underlying zoom event consumes the mouse event.
        // Thus there are problems when we go to zoom in at a particular point
        // See reference note about why we stop event propagation: http://bl.ocks.org/robschmuecker/7880033
        // See also: https://github.com/mbostock/d3/wiki/Drag-Behavior#on
        d3.event.sourceEvent.stopPropagation();
        d3.event.sourceEvent.preventDefault();

        // Indicate the node has stopped dragging
        self.flagIsInNodeDrag = false;

        // Remove the drag class class after
        // the animation has finish
        var removeClassAfterTransitionFinished = function () {
            // remove event listeners
            self._.on('transitionend.sb_event_drag_end', null);
            self._.on('webkitTransitionEnd.sb_event_drag_end', null);
            self._.on('oTransitionEnd.sb_event_drag_end', null);
            self._.on('MSTransitionEnd.sb_event_drag_end', null);

            // remove the class
            self._.classed('sb-event-drag-end', false);
        };
        self._.on('transitionend.sb_event_drag_end', removeClassAfterTransitionFinished)
            .on('webkitTransitionEnd.sb_event_drag_end', removeClassAfterTransitionFinished)
            .on('oTransitionEnd.sb_event_drag_end', removeClassAfterTransitionFinished)
            .on('MSTransitionEnd.sb_event_drag_end', removeClassAfterTransitionFinished);

        // Apply appropriate classes
        self._.classed('sb-event-drag', false);
        self._.classed('sb-event-drag-start', false);
        self._.classed('sb-event-drag-end', true);

        // Remove all active classes
        self._.selectAll('.sb-event-drag-active').classed('sb-event-drag-active', false);

        return self;
    };


    /**
     * Called when dragging nodes
     * @param that Context of the caller
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._onNodeDrag = function (that) {
        var self  = this,
            elemn = d3.select(that),
            id    = elemn.attr('data-sb-node-id');

        // Update the current origin to this event
        self._dragCurrentOrigin = d3.event.sourceEvent;

        // Check if the node is dragged
        var originScreenX = self._dragStartingOrigin.screenX;
        var originScreenY = self._dragStartingOrigin.screenY;
        var currentScreenX = d3.event.sourceEvent.screenX;
        var currentScreenY = d3.event.sourceEvent.screenY;

        if (originScreenX == currentScreenX && originScreenY == currentScreenY) {
            self._isInDrag = false;
            return self;
        }

        // Indicates that is in drag mode. Don't triggered
        // any synthetic events
        self._isInDrag = true;


        // As far as I've observed, the underlying zoom event consumes the mouse event.
        // Thus there are problems when we go to zoom in at a particular point
        // See reference note about why we stop event propagation: http://bl.ocks.org/robschmuecker/7880033
        // See also: https://github.com/mbostock/d3/wiki/Drag-Behavior#on
        d3.event.sourceEvent.stopPropagation();
        d3.event.sourceEvent.preventDefault();

        // translate the current node
        elemn.attr("transform", "translate(" + d3.event.x + "," + d3.event.y + ")");

        // Fetch the node and then redraw connections
        var sourceNode = self.fetchNodeById(id);
        if (sourceNode != null) {
            Utils.forEach(sourceNode.edges, function (edge) {
                self._drawPathConnection(edge);
                edge._.classed('sb-event-drag-active', true);
                edge.srcNode._.classed('sb-event-drag-active', true);
                edge.destNode._.classed('sb-event-drag-active', true);
            });
        } else {
            var groupElemnt = self.fetchNodeGroupById(elemn.attr('data-sb-node-group-id'));
            Utils.forEach(groupElemnt.nodes, function (node) {
                Utils.forEach(node.edges, function (edge) {
                    self._drawPathConnection(edge);
                    edge._.classed('sb-event-drag-active', true);
                });
            });
        }

        self._drawEdgeGroups();

        return self;
    };

    //</editor-fold>


    //<editor-fold desc="Path trace">

    /**
     * Starts the path-tracing mode for edge
     * @param {Edge} edge Edge to start tracing animation on
     * @param {Node} startingNode Find the edge that starts at this node
     * @param {boolean} shouldEmphasize Should emphasize the edge
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.pathTracingEnter = function (edge, startingNode, shouldEmphasize) {

        if (!edge || !(edge instanceof Edge)) {
            throw new Error('Specified edge not instance of "Edge".');
        }

        var pathtraceClass = 'sb-path-trace';

        // The path is always started from the srcNode.
        // Thus if the user wants to run in reverse, give that option
        if (startingNode && (startingNode instanceof Node) && edge.srcNode.id != startingNode.id) {
            pathtraceClass = 'sb-path-trace-reverse';
        }

        edge._.classed('sb-path-trace', false);
        edge._.classed('sb-path-trace-no-animation', false);
        edge._.classed('sb-path-trace-reverse', false);
        edge._.classed('sb-path-trace-emphasize', false);

        edge._.classed(pathtraceClass, true);

        if (shouldEmphasize) {
            edge._.classed('sb-path-trace-emphasize', true);
        }

        this._moveRightBehindFirstNodeOrNodeGroup(edge._.node());

        return this;
    };


    /**
     * Leave the path-tracing mode for edge
     * @param {Edge} edge Edge to leave tracing animation from
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.pathTracingLeave = function (edge) {
        if (edge instanceof Edge) {
            edge._.classed('sb-path-trace', false);
            edge._.classed('sb-path-trace-no-animation', false);
            edge._.classed('sb-path-trace-reverse', false);
            edge._.classed('sb-path-trace-emphasize', false);
        }
        return this;
    };


    /**
     * Leave all path tracing
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.pathTracingLeaveAll = function () {
        this._root.selectAll('.sb-path-trace').classed('sb-path-trace', false);
        this._root.selectAll('.sb-path-trace-no-animation').classed('sb-path-trace-no-animation', false);
        this._root.selectAll('.sb-path-trace-reverse').classed('sb-path-trace-reverse', false);
        this._root.selectAll('.sb-path-trace-emphasize').classed('sb-path-trace-emphasize', false);
        return this;
    };


    /**
     * Add emphasis to a given DOM element
     * @param {Element} elemn
     * @param {boolean} shouldAdd True to add. False to remove
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.pathTraceEmphasize = function (elemn, shouldAdd) {
        d3.select(elemn).classed('sb-path-trace-emphasize', shouldAdd);
        return this;
    };

    //</editor-fold>


    //<editor-fold desc="Select Multiple">

    SevenBridges.prototype._selectionAttachBlurFilter = function () {
        var self = this;
        //if (!self._selectionIsGlowFilterSet) {
        //Container for the gradients
        var defs = self._.append("defs");

        // Filter for the outside glow
        var filter = defs.append("filter").attr("id","sb-selection-glow");
        filter.append("feGaussianBlur")
            .attr("stdDeviation","2.5")
            .attr("result","coloredBlur");
        var feMerge = filter.append("feMerge");
        feMerge.append("feMergeNode")
            .attr("in","coloredBlur");
        feMerge.append("feMergeNode")
            .attr("in","SourceGraphic");
        //    self._selectionIsGlowFilterSet = true;
        //}
        return self;
    };


    /**
     * Called when the selection first starts.
     * @param {MouseEvent} evt
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._onSelectionStart = function (evt) {
        var self = this;
        var x = d3.event.layerX;
        var y = d3.event.layerY;

        self._selectionAttachBlurFilter();

        if (!self._selectionRect) {
            self._selectionRect = self._.append("rect")
                .attr("class", "sb-selection-rect");
        }

        self._selectionRect.attr("x", x).attr("y", y);
        self._selectionStartingCoords = { x: x, y: y };
        self._root.classed('sb-selection-started', true);

        // Clear all selections
        self.clearSelected();

        return self;
    };


    /**
     * Called when the selection end starts.
     * @param {MouseEvent} evt
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._onSelectionEnd = function (evt) {
        var self = this;
        if (self._selectionRect) {
            self._selectionRect.remove();
            self._selectionRect = null;
            self._selectionStartingCoords = null;
        }
        self._root.classed('sb-selection-started', false);
        self.dispatcher.onselectionend();
        return self;
    };


    /**
     * Called when the selection moves
     * @param {MouseEvent} evt
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._onSelection = function (evt) {
        var self = this;

        if (d3.event && self._selectionRect && self._selectionStartingCoords) {
            var origin = self._selectionStartingCoords;
            var x = d3.event.layerX;
            var y = d3.event.layerY;
            var width = Math.abs(x - origin.x) || 0.001;
            var height = Math.abs(y - origin.y) || 0.001;
            // handle the case if the user is selecting
            // behind the starting origin
            var scaleX = x < origin.x ? -1 : 1;
            var scaleY = y < origin.y ? -1 : 1;
            var translateX = scaleX < 1 ? 2*origin.x : 0;
            var translateY = scaleY < 1 ? 2*origin.y : 0;
            self._selectionRect.attr("transform", "translate(" + translateX + "," + translateY + ") scale(" + scaleX + "," + scaleY + ")");
            self._selectionRect.attr("width", width);
            self._selectionRect.attr("height", height);

            var bboxRect = self._selectionRect.node().getBoundingClientRect();
            self.forEachNode(function (node) {
                var bbox = node._.node().getBoundingClientRect();
                if (self._detectCollision(bboxRect, bbox)) {
                    node._.classed('sb-selection-selected', true);
                } else {
                    node._.classed('sb-selection-selected', false);
                }
            });
        }
    };


    /**
     * Called when the a node is click
     * @param {MouseEvent} evt
     * @param {Node} node
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._onSelectionNodeClick = function (node) {
        this._selectionAttachBlurFilter();
        var classname = 'sb-selection-selected';
        node._.classed(classname, !node._.classed(classname));
        return this;
    };


    /**
     * Detects collision between two bounding boxes
     * or bounding rectangles
     * @param rect1
     * @param rect2
     * @returns {boolean}
     * @private
     */
    SevenBridges.prototype._detectCollision = function (rect1, rect2) {
        // Credits: https://developer.mozilla.org/en-US/docs/Games/Techniques/2D_collision_detection
        rect1.x = rect1.x || rect1.left;
        rect1.y = rect1.y || rect1.top;
        rect2.x = rect2.x || rect2.left;
        rect2.y = rect2.y || rect2.top;
        return (rect1.x < rect2.x + rect2.width &&
        rect1.x + rect1.width > rect2.x &&
        rect1.y < rect2.y + rect2.height &&
        rect1.height + rect1.y > rect2.y);
    };


    /**
     * Clear the selection
     * @returns {SevenBridges}
     */
    SevenBridges.prototype.clearSelected = function () {
        return this.forEachNode(function (node) {
            node._.classed('sb-selection-selected', false);
        });
    };


    /**
     * Get a list of all the selected nodes
     * @returns {Array<Node>}
     */
    SevenBridges.prototype.selected = function () {
        var selected = [];
        this.forEachNode(function (node) {
            if (node._.classed('sb-selection-selected')) {
                selected.push(node);
            }
        });
        return selected;
    };


    /**
     * Set whether to enter selection mode. selection
     * mode enables you to select multiple nodes
     * that you can later retrieve using the
     * {@link #selected()} method
     * @param {boolean} enterSelectionMode true to enter selection mode
     *                  false to leave selection mode
     * @returns {SevenBridges}
     */
    SevenBridges.prototype.selectionMode = function (enterSelectionMode) {
        this.flagIsInSelectionMode = enterSelectionMode;
        return this;
    };

    //</editor-fold>


    //<editor-fold desc="Zooming">

    /**
     * Called on zoom stop
     * @param that
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._onZoomStart = function (that) {
        Log.info('Zooming START | _onZoomStart()', that);
        return this;
    };


    /**
     * Called on zoom start
     * @param that
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._onZoomEnd = function (that) {
        Log.info('Zooming END | _onZoomEnd()', that);
        return this;
    };


    /**
     * Called on the zoom
     * @param that Context of the caller
     * @returns {SevenBridges}
     * @private
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype._onZoom = function (that) {
        var self = this;

        if (!self.flagIsInNodeDrag && !self.flagIsInSelectionMode) {
            Log.info('Zooming: panning mode | _onZoom()', that);
            self._root.attr("transform", "translate(" + d3.event.translate + ") scale(" + d3.event.scale + ")");
        }
        return self;
    };


    /**
     * Fit the contents to the view-port
     * @param {number} transitionDuration The duration time for animation
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.zoomFit = function (transitionDuration) {
        // Adopted from: http://stackoverflow.com/a/31236280
        // There is a bug in FireFox where the MouseEvent is null
        // Thus the entire zoom-fitting fails. Use the approach
        // shown here.
        var self = this,
            rootBounds = self._root.node().getBBox(),
            rootParentNodeBounds = self._.node().getBoundingClientRect(),
            width = rootBounds.width,
            height = rootBounds.height,
            midX = rootBounds.x + width / 2,
            midY = rootBounds.y + height / 2;

        // Apply translation
        if (width != 0 && height != 0) {
            var scale = 0.9 / Math.max(width / rootParentNodeBounds.width, height / rootParentNodeBounds.height);
            //console.log('scale', scale);
            var scale = 1.5;
            var translation = [rootParentNodeBounds.width / 2 - scale * midX, rootParentNodeBounds.height / 2 - scale * midY];

            // The following sets a sentinel and watches it before dispatching endAll
            // Technique is described here: http://stackoverflow.com/a/26497138
            var n = 0;
            if (self._.length <= 0) {
                self.dispatcher.drawfinish();
            } else {
                self._
                    .each(function () {
                        n++;
                    })
                    .transition()
                    .duration(transitionDuration || self.config.defaultAnimationTime) // milliseconds
                    .each('end', function () {
                        n--;
                        if (!n) {
                            self.dispatcher.drawfinish();
                        }
                    })
                    .call(self.zoomEventHandler.translate(translation).scale(scale).event);
            }

            /*self._.transition()
             .duration(transitionDuration || self.config.defaultAnimationTime) // milliseconds
             .call(self.zoomEventHandler.translate(translation).scale(scale).event);*/
        } else {
            self.dispatcher.drawfinish();
        }

        return self;
    };


    /**
     * Zoom in and out by a given factor. All zoom-transformations
     * are done from the center of the viewport.
     *
     * @param {number} factor Pass in a value less than 1 to zoom-out.
     *                        Greater than 1 to zoom-in
     * @param {number} transitionDuration Animation time
     * @returns {SevenBridges}
     */
    SevenBridges.prototype.zoomByFactor = function(factor, transitionDuration) {
        var self = this;

        // Credits: http://stackoverflow.com/a/21653008
        var vis = self._,
            zoom = self.zoomEventHandler,
            bounds = self._.node().getBoundingClientRect(),
            width = bounds.width,
            height = bounds.height,
            scale = zoom.scale(),
            extent = zoom.scaleExtent(),
            newScale = scale * factor;

        if (extent[0] <= newScale && newScale <= extent[1]) {
            var t = zoom.translate();
            var c = [width / 2, height / 2];
            zoom.scale(newScale)
                .translate([c[0] + (t[0] - c[0]) / scale * newScale, c[1] + (t[1] - c[1]) / scale * newScale])
                .event(vis.transition().duration(transitionDuration || self.config.defaultAnimationTime));
        }

        return self;
    };


    /**
     * Zoom out from the center
     * @param {number} zoomOutFactor Value less than 1
     * @param {number} transitionDuration Animation time
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.zoomOut = function (zoomOutFactor, transitionDuration) {
        return this.zoomByFactor(zoomOutFactor || 0.6, transitionDuration);
    };


    /**
     * Zoom in from the center
     * @param {number} zoomInFactor Value greater than 1
     * @param {number} transitionDuration Animation time
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.zoomIn = function (zoomInFactor, transitionDuration) {
        return this.zoomByFactor(zoomInFactor || 1.8, transitionDuration)
    };

    //</editor-fold>


    //<editor-fold desc="Search">

    /**
     * Search enter. Mostly for applying CSS changes to DOM
     * @param {boolean} shouldTrace if search should happen in trace mode
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.searchEnter = function (shouldTrace) {
        var self = this;
        self._.classed('sb-event-search-leave', false);
        self._.classed('sb-event-search', true);
        if (shouldTrace) {
            self._.classed('sb-event-search-trace', true);
        }
        return self;
    };


    /**
     * Search leave. Remove the stylings for CSS leave
     * @returns {SevenBridges}
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.searchLeave = function () {
        var self = this;

        // Remove the search class class after
        // the animation has finish
        var removeClassAfterTransitionFinished = function () {
            // remove event listeners
            self._.on('transitionend.sb_event_search_end', null);
            self._.on('webkitTransitionEnd.sb_event_search_end', null);
            self._.on('oTransitionEnd.sb_event_search_end', null);
            self._.on('MSTransitionEnd.sb_event_search_end', null);

            // remove the class
            self._.classed('sb-event-search-leave', false);
            self._.classed('sb-event-search-trace', false);
        };
        self._.on('transitionend.sb_event_search_end', removeClassAfterTransitionFinished)
            .on('webkitTransitionEnd.sb_event_search_end', removeClassAfterTransitionFinished)
            .on('oTransitionEnd.sb_event_search_end', removeClassAfterTransitionFinished)
            .on('MSTransitionEnd.sb_event_search_end', removeClassAfterTransitionFinished);

        // Apply appropriate classes
        self._.classed('sb-event-search', false);
        self._.classed('sb-event-search-leave', true);
        self.removeClassFromNodes("sb-event-search-active");
        self.removeClassFromEdges("sb-event-search-active");

        return self;
    };


    /**
     * The search to perform
     * @param {String} searchTerm
     * @returns {object} List of matches
     * @memberOf SevenBridges
     * @instance
     */
    SevenBridges.prototype.search = function (searchTerm) {
        var self = this;
        var classNameActive = "sb-event-search-active";
        var matches = {
            nodes: [],
            edges: []
        };

        /**
         * Default properties to search
         * @type {string[]}
         */
        var defaultPropertiesToSearch = self.config.searchableProperties;

        /**
         * The search keywords
         */
        var searchRules = (function () {

            /**
             * This search rule is based on using asterisk as wildcard
             * Based on: http://stackoverflow.com/a/32402438
             * @param {string} rule
             */
            function getSearchRule(rule) {
                rule = Utils.strTrim(rule);
                // If quotations and wildcard are not supplied,
                // convert to a wildcard rule
                if (!Utils.strContains(rule, '"') && !Utils.strContains(rule, "'") && !Utils.strContains(rule, "*")) {
                    rule = "*" + rule + "*";
                }
                rule = Utils.strReplaceAll(rule, "'", "");
                rule = Utils.strReplaceAll(rule, '"', "");

                return new RegExp("^" + Utils.strReplaceAll(rule, "*", ".*") + "$", "i");
            }

            // Convert each search term into a Regex search rule
            if (!Utils.strIsNullOrWhiteSpace(searchTerm)) {
                var rules = [];
                Utils.forEach((searchTerm.split(/[\s,]+/)), function (rule) {
                    if (!Utils.strIsNullOrWhiteSpace(rule)) {
                        var split = rule.split("=");
                        if (split.length > 1) { // If the user specified a "=", then search that specific property
                            rules.push({
                                propName: Utils.strTrim(split[0]),
                                rule: getSearchRule(split[1])
                            });
                        } else { // Otherwise search the default searchable properties
                            var searchRule = getSearchRule(rule);
                            Utils.forEach(defaultPropertiesToSearch, function (propName) {
                                rules.push({
                                    propName: propName,
                                    rule: searchRule
                                });
                            });
                        }
                    }
                });
                return rules;
            }
            // default return empty
            return [];
        }());

        /**
         *
         * @param {object} obj
         * @returns {boolean}
         */
        function isMatch(obj) {
            if (obj) {
                for (var i = 0; i < searchRules.length; i++) {
                    var searchRule = searchRules[i];
                    var value = Utils.safeToString(Utils.getSetDescendantProp(obj, searchRule.propName));
                    if (searchRule.rule.test(value)) {
                        return true;
                    }
                }
            }
            return false;
        }


        // Iterate through the nodes and edge set looking at specific properties
        if (searchRules.length > 0) {
            // Search the nodes
            self.forEachNode(function(node) {
                if (node && node._) {
                    if (isMatch(node)) {
                        node._.classed(classNameActive, true);
                        matches.nodes.push(node);
                    } else {
                        node._.classed(classNameActive, false);
                    }
                }
            });

            // Search the edge set
            self.forEachEdge(function (edge) {
                if (edge && edge._) {
                    if (isMatch(edge)) {
                        edge._.classed(classNameActive, true);
                        matches.edges.push(edge);
                    } else {
                        edge._.classed(classNameActive, false);
                    }
                }
            });
        } else {
            self.removeClassFromNodes(classNameActive).removeClassFromEdges(classNameActive);
        }

        return matches;
    };

    //</editor-fold>


    //<editor-fold desc="Export">

    SevenBridges.prototype.export = function () {
        return SevenBridges.export(this);
    };

    /**
     * Indicates if export is available within the browser
     * @returns {boolean}
     */
    SevenBridges.isExportAvailable = function () {
        var isCanvasSupported = function () {
            var elem = document.createElement('canvas');
            return !!(elem.getContext && elem.getContext('2d'));
        };
        return isCanvasSupported();
    };

    SevenBridges.export = function (sbInstanceOrSvgNode) {
        var filename = "topology.png";
        var width    = window.screen.width * 1;
        var height   = window.screen.height * 1;
        var node     = (sbInstanceOrSvgNode instanceof SevenBridges)
            ? sbInstanceOrSvgNode._.node().cloneNode(true)
            : sbInstanceOrSvgNode.cloneNode(true);

        //node.id = "sb_cloned_" + node.id;
        node.style.width = width + "px";
        node.style.height = height + "px";

        // Recursively walk DOM
        var walkDOM = function (node, func) {
            func(node);
            node = node.firstChild;
            while (node) {
                walkDOM(node,func);
                node = node.nextSibling;
            }
        };

        // Update the IDs
        walkDOM(node, function (nd) {
            if (nd.getAttribute && nd.setAttribute) {
                var id = nd.getAttribute('id');
                if (id) {
                    nd.setAttribute('id', "sb_cloned_" + id);
                }
            }
        });


        function zoomFit(root) {
            var bounds = root.node().getBBox();
            var parent = root.node().parentElement;
            var fullWidth = window.screen.width * 1,
                fullHeight = window.screen.height * 1;
            var width = bounds.width,
                height = bounds.height;
            var midX = bounds.x + width / 2,
                midY = bounds.y + height / 2;
            if (width == 0 || height == 0) return; // nothing to fit
            var scale = 1 / Math.max(width / fullWidth, height / fullHeight);
            var translate = [fullWidth / 2 - scale * midX, fullHeight / 2 - scale * midY];

            console.trace("zoomFit", translate, scale);

            /*root
             .transition()
             .duration(transitionDuration || 0) // milliseconds
             .call(zoom.translate(translate).scale(scale).event);*/
            root.attr('transform', 'translate(' + translate[0] + ',' + translate[1] + ') scale(' + scale + ')');
        }




        var svg_el = node;
        var crowbar_el = document.createElement('div');
        document.body.appendChild(crowbar_el);
        document.body.appendChild(node);

        zoomFit(d3.select(node).select('g'));


        // apply the stylesheet to the svg to be sure to capture all of the stylings
        applyStylesheets(svg_el);

        // grab the html from the svg and encode the svg in a data url
        var html = svg_el.outerHTML;
        var imgsrc = 'data:image/svg+xml;base64,' + btoa(html);


        saveSvgAsPng(node, {scale: 2});

        /*var a = document.createElement("a");
         //a.download = filename;
         a.target = '_blank';
         a.href = imgsrc;
         a.click();



         // create a canvas element that has the right dimensions
         crowbar_el.innerHTML = (
         '<canvas width="' + width + '" height="' + height + '"></canvas>'
         )
         var canvas = crowbar_el.querySelector("canvas");
         var context = canvas.getContext("2d");
         var image = new Image(width, height);

         image.onload = function() {

         // draw the image in the context of the canvas and then get the
         // image data from the canvas
         //
         // TODO: the resulting canvas image is a little on the grainy side.
         // up until this point the image is lossless, so it definitely has
         // something to do with the imgsrc getting lost when embedding in
         // the canvas. this appears to be a problem with just about
         // anything i've seen
         context.drawImage(image, 0, 0);
         var canvasdata = canvas.toDataURL("image/png");

         // download the data
         var a = document.createElement("a");
         //a.download = filename;
         a.target = '_blank';
         a.href = canvasdata;
         a.click();
         };

         image.src = imgsrc;
         image.onload();*/

        // this is adapted (barely) from svg-crowbar
        // https://github.com/NYTimes/svg-crowbar/blob/gh-pages/svg-crowbar-2.js#L211-L250
        function applyStylesheets(svgEl) {

            // use an empty svg to compute the browser applied stylesheets
            var emptySvg = window.document.createElementNS("http://www.w3.org/2000/svg", 'svg');
            window.document.body.appendChild(emptySvg);
            var emptySvgDeclarationComputed = getComputedStyle(emptySvg);
            emptySvg.parentNode.removeChild(emptySvg);

            // traverse the element tree and explicitly set all stylesheet values
            // on an element. this is ripped from svg-crowbar
            var allElements = traverse(svgEl);
            var i = allElements.length;
            while (i--){
                explicitlySetStyle(allElements[i], emptySvgDeclarationComputed);
            }
        }


        function explicitlySetStyle (element, emptySvgDeclarationComputed) {
            var cSSStyleDeclarationComputed = getComputedStyle(element);
            var i, len, key, value;
            var computedStyleStr = "";
            for (i=0, len=cSSStyleDeclarationComputed.length; i<len; i++) {
                key=cSSStyleDeclarationComputed[i];
                value=cSSStyleDeclarationComputed.getPropertyValue(key);
                if (value!==emptySvgDeclarationComputed.getPropertyValue(key)) {
                    computedStyleStr+=key+":"+value+";";
                }
            }
            element.setAttribute('style', computedStyleStr);
        }


        // traverse an svg and append all of the elements to the tree array. This
        // ignores some elements that can appear in <svg> elements but whose
        // children's styles should not be tweaked
        function traverse(obj){
            var tree = [];
            var ignoreElements = {
                'script': undefined,
                'defs': undefined,
            };
            tree.push(obj);
            visit(obj);
            function visit(node) {
                if (node && node.hasChildNodes() && !(node.nodeName.toLowerCase() in ignoreElements)) {
                    var child = node.firstChild;
                    while (child) {
                        if (child.nodeType === 1) {
                            tree.push(child);
                            visit(child);
                        }
                        child = child.nextSibling;
                    }
                }
            }
            return tree;
        }


        //return node;
    };

    //</editor-fold>

    //</editor-fold>


    //<editor-fold desc="Library export">

    // Export the library
    if (typeof module != "undefined" && module.exports) {
        module.exports = SevenBridges;
    } else if (typeof define === "function" && define.amd) {
        define(SevenBridges);
    } else {
        global.SevenBridges = SevenBridges;
    }

    //</editor-fold>


})(this, d3, jQuery);
