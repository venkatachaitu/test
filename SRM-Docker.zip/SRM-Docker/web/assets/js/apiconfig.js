
/* Development Mode */
//var serverIpAddress = 'http://10.126.177.52';

/*Build Mode */
var serverIpAddress = 'http://172.22.31.18';

var topology = serverIpAddress+":8301/";
var templateServices = serverIpAddress+":8302/";

var apiConfig = {
    "getDiscovery": topology+"/topology",
    //"getDiscovery": "assets/json/topology.json",
    "getSubnets": templateServices+"/subnets",
    //"getSubnets": "assets/json/subnets.json",
    "getPolicies": templateServices+"/policies",
    //"getPolicies": "assets/json/policies.json",
    "getStaticConfig": templateServices+"/config",
    //"getStaticConfig": "assets/json/config.json",
    "postStaticConfig": templateServices+"/pushconfig",
    //"topoCustomLayout": "assets/json/layout.json",
    "topoCustomLayout": templateServices+"/layout",
    //"getTenants": "assets/json/tenent.json",
    "getTenants": templateServices+"/tenants",
    "getInterfaces": "assets/json/interfaces.json",
    "postTenantConfig": templateServices+"/pushtenantconfig"
};

apiConfig;