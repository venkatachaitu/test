package com.cisco.segment.templateEngineservice.model;

import org.springframework.stereotype.Component;
import com.fasterxml.jackson.annotation.JsonProperty;

@Component
public class TemplateCLI {

	@JsonProperty
	public String policy;
	@JsonProperty
	public String inLabel;
	@JsonProperty
	public String subnet;
	@JsonProperty
	public String nextHop;
	@JsonProperty
	public String connectingHops;
	@JsonProperty
	public String sourceSwitchIP;
	@JsonProperty
	public String pushMode;
}
