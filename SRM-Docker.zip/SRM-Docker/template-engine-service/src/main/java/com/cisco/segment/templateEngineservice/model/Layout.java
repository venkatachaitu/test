package com.cisco.segment.templateEngineservice.model;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;

@Component
public class Layout {
	@JsonProperty
	public String layout;
}
