package com.cisco.segment.templateEngineservice.utils;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Component;

import com.cisco.segment.templateEngineservice.model.Layout;
import com.cisco.segment.templateEngineservice.model.ResponceCustom;
import com.cisco.segment.templateEngineservice.model.Subnets;
import com.cisco.segment.templateEngineservice.model.Tenant;
import com.cisco.segment.templateEngineservice.model.SubnetConfig;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class JsonFileHandlerImpl implements JsonFileHandler {
	@SuppressWarnings("unchecked")
	public ResponceCustom addPolicy(ResponceCustom policy) throws Exception {
		JSONParser parser = new JSONParser();
		org.json.JSONObject jsonObject = null;
		 try {
		    	ObjectMapper mapper = new ObjectMapper();
		    	String jsonInString = mapper.writeValueAsString(policy);
				jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(policy);
				jsonObject = new org.json.JSONObject(jsonInString);

				JSONArray ar = (JSONArray) parser.parse(new FileReader("test.json"));
				/*for (int i = 0; i < ar.size(); i++) {
					Object o = ar.get(i);
	        	    JSONObject policy1 = (JSONObject) o;	        	    
					if(policy1.get("POLICY_NAME").toString().equals(policy.POLICY_NAME.toString())){
			    	    return null;
					}
	        	}*/
				ar.add(jsonObject);
				FileWriter file = new FileWriter("test.json");
		    	file.write(ar.toJSONString());
	    	    file.flush();
	    	    file.close();
	    	    return policy;	    	    
	    } catch (Exception e) {
	    	JSONArray ar = new JSONArray();
			ar.add(jsonObject);
			FileWriter file;
			file = new FileWriter("test.json");
	    	file.write(ar.toJSONString());
    	    file.flush();
    	    file.close();
	    	System.out.println("addPolicy() : "+e);
	    	return policy;
	    }
	}
	
	@SuppressWarnings("rawtypes")
	public Map<String, List> getPolicies(){
		Map<String, List> map = new HashMap<String, List>();
		List<Object> li = new ArrayList<Object>();
		JSONParser parser = new JSONParser();
		try {     
        	JSONArray a = (JSONArray) parser.parse(new FileReader("test.json"));
        	for (int i = 0; i < a.size(); i++) {
        		Object o = a.get(i);
        		li.add(o);
        	  }
        } catch (Exception e) {
        	System.out.println("getPolicies() : "+e);
        }
		map.put("policies", li);
		return map;		
	}
	
	@SuppressWarnings("unchecked")
	public ResponceCustom updatePolicy(ResponceCustom policy) {
		JSONParser parser = new JSONParser();
		org.json.JSONObject jsonObject = null;
		try {     
        	org.json.simple.JSONArray ar = (org.json.simple.JSONArray) parser.parse(new FileReader("test.json"));
        	for (int i = 0; i < ar.size(); i++) {
        		Object o = ar.get(i);
        	    JSONObject policy1 = (JSONObject) o;  
        	    if(policy1.get("POLICY_NAME").toString().equals(policy.POLICY_NAME.toString())){
            	    ar.remove(i);
            	    ObjectMapper mapper = new ObjectMapper();
    		    	String jsonInString = mapper.writeValueAsString(policy);
    				jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(policy);
    				jsonObject = new org.json.JSONObject(jsonInString);   
    				ar.add(jsonObject);    				
    				FileWriter file = new FileWriter("test.json");
    		    	file.write(ar.toString());
    	    	    file.flush();
    	    	    file.close();
    	    	    return policy;
        	    }
        	}
    	} catch (Exception e) {
        	System.out.println("updatePolicy() : "+e);
        }
		return null;
	}

	public boolean deletePolicy(ResponceCustom policy) {
		JSONParser parser = new JSONParser();
		try {     
        	org.json.simple.JSONArray ar = (org.json.simple.JSONArray) parser.parse(new FileReader("test.json"));
        	for (int i = 0; i < ar.size(); i++) {
        		Object o = ar.get(i);
        	    JSONObject policy1 = (JSONObject) o;  
        	    if(policy1.get("POLICY_NAME").toString().equals(policy.POLICY_NAME.toString())){
            	    ar.remove(i);
            	    FileWriter file = new FileWriter("test.json");
    		    	file.write(ar.toString());
    	    	    file.flush();
    	    	    file.close();
    	    	    return true;
        	    }
        	}
    	} catch (Exception e) {
        	System.out.println("deletePolicy() : "+e);
        }
		return false;
	}

	@SuppressWarnings("unchecked")
	@Override	
	public SubnetConfig createVrfService(SubnetConfig policy) throws Exception {
		JSONParser parser = new JSONParser();
		org.json.JSONObject jsonObject = null;
		 try {
			 if(policy.id == null){
					Thread.sleep(1000);
					policy.id = new SimpleDateFormat("dd HH:mm:ss").format(Calendar.getInstance().getTime()).replaceAll("[^a-zA-Z0-9]", "").toString();
			 }
		    	ObjectMapper mapper = new ObjectMapper();
		    	String jsonInString = mapper.writeValueAsString(policy);
				jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(policy);
				jsonObject = new org.json.JSONObject(jsonInString);

				JSONArray ar = (JSONArray) parser.parse(new FileReader("SubnetConfig.json"));
				/*for (int i = 0; i < ar.size(); i++) {
					Object o = ar.get(i);
	        	    JSONObject policy1 = (JSONObject) o;	        	    
					if(policy1.get("POLICY_NAME").toString().equals(policy.POLICY_NAME.toString())){
			    	    return null;
					}
	        	}*/
				ar.add(jsonObject);
				FileWriter file = new FileWriter("SubnetConfig.json");
		    	file.write(ar.toJSONString());
	    	    file.flush();
	    	    file.close();
	    	    return policy;	    	    
	    } catch (Exception e) {
	    	JSONArray ar = new JSONArray();
			ar.add(jsonObject);
			FileWriter file;
			file = new FileWriter("SubnetConfig.json");
	    	file.write(ar.toJSONString());
    	    file.flush();
    	    file.close();
	    	System.out.println("createVrfService() : "+e);
	    	return policy;
	    }
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public Map<String, List> getVrfService() {
		Map<String, List> map = new HashMap<String, List>();
		List<Object> li = new ArrayList<Object>();
		JSONParser parser = new JSONParser();
		try {     
        	JSONArray a = (JSONArray) parser.parse(new FileReader("SubnetConfig.json"));
        	for (int i = 0; i < a.size(); i++) {
        		Object o = a.get(i);
        		li.add(o);
        	  }
        } catch (Exception e) {
        	System.out.println("getVrfService() : "+e);
        }
		map.put("config", li);
		return map;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public SubnetConfig updateVrfService(SubnetConfig policy) {

		JSONParser parser = new JSONParser();
		org.json.JSONObject jsonObject = null;
		try {     
        	org.json.simple.JSONArray ar = (org.json.simple.JSONArray) parser.parse(new FileReader("SubnetConfig.json"));
        	for (int i = 0; i < ar.size(); i++) {
        		Object o = ar.get(i);
        	    JSONObject policy1 = (JSONObject) o;  
        	    if(policy1.get("id").toString().equals(policy.id.toString())){
        	    	policy1.remove("isDeployed");
        	    	policy1.put("isDeployed", policy.isDeployed);
        	    	ar.remove(i);
            	    //ar.add(policy1);
            	    ObjectMapper mapper = new ObjectMapper();
    		    	String jsonInString = mapper.writeValueAsString(policy1);
    				jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(policy1);
    				jsonObject = new org.json.JSONObject(jsonInString);   
    				ar.add(jsonObject);    				
    				FileWriter file = new FileWriter("SubnetConfig.json");
    		    	file.write(ar.toString());
    	    	    file.flush();
    	    	    file.close();
    	    	    return policy;
        	    }
        	}
    	} catch (Exception e) {
        	System.out.println("updateSubnets() : "+e);
        }
		return null;	
	}

	@SuppressWarnings("unchecked")
	@Override
	public Subnets createSubnet(Subnets subnet) throws Exception {
		JSONParser parser = new JSONParser();
		org.json.JSONObject jsonObject = null;
		 try {
			 if(subnet.id == null){
				Thread.sleep(1000);
				 subnet.id = new SimpleDateFormat("dd HH:mm:ss").format(Calendar.getInstance().getTime()).replaceAll("[^a-zA-Z0-9]", "").toString();
			 }
		    	ObjectMapper mapper = new ObjectMapper();
		    	String jsonInString = mapper.writeValueAsString(subnet);
				jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(subnet);
				jsonObject = new org.json.JSONObject(jsonInString);

				JSONArray ar = (JSONArray) parser.parse(new FileReader("Subnets.json"));
				/*for (int i = 0; i < ar.size(); i++) {
					Object o = ar.get(i);
	        	    JSONObject policy1 = (JSONObject) o;	        	    
					if(policy1.get("POLICY_NAME").toString().equals(policy.POLICY_NAME.toString())){
			    	    return null;
					}
	        	}*/
				ar.add(jsonObject);
				FileWriter file = new FileWriter("Subnets.json");
		    	file.write(ar.toJSONString());
	    	    file.flush();
	    	    file.close();
	    	    return subnet;	    	    
	    } catch (Exception e) {
	    	JSONArray ar = new JSONArray();
			ar.add(jsonObject);
			FileWriter file;
			file = new FileWriter("Subnets.json");
	    	file.write(ar.toJSONString());
    	    file.flush();
    	    file.close();
	    	System.out.println("createSubnet() : "+e);
	    	return subnet;
	    }
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Map<String, List> getSubnets() {
		Map<String, List> map = new HashMap<String, List>();
		List<Object> li = new ArrayList<Object>();
		JSONParser parser = new JSONParser();
		try {     
        	JSONArray a = (JSONArray) parser.parse(new FileReader("Subnets.json"));
        	for (int i = 0; i < a.size(); i++) {
        		Object o = a.get(i);
        		li.add(o);
        	  }
        } catch (Exception e) {
        	System.out.println("getSubnets() : "+e);
        }
		map.put("subnets", li);
		return map;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Subnets updateSubnets(Subnets subnet) {

		JSONParser parser = new JSONParser();
		org.json.JSONObject jsonObject = null;
		try {     
        	org.json.simple.JSONArray ar = (org.json.simple.JSONArray) parser.parse(new FileReader("Subnets.json"));
        	for (int i = 0; i < ar.size(); i++) {
        		Object o = ar.get(i);
        	    JSONObject policy1 = (JSONObject) o;  
        	    if(policy1.get("id").toString().equals(subnet.id.toString())){
            	    ar.remove(i);
            	    ObjectMapper mapper = new ObjectMapper();
    		    	String jsonInString = mapper.writeValueAsString(subnet);
    				jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(subnet);
    				jsonObject = new org.json.JSONObject(jsonInString);   
    				ar.add(jsonObject);    				
    				FileWriter file = new FileWriter("Subnets.json");
    		    	file.write(ar.toString());
    	    	    file.flush();
    	    	    file.close();
    	    	    return subnet;
        	    }
        	}
    	} catch (Exception e) {
        	System.out.println("updateSubnets() : "+e);
        }
		return null;	
	}

	@Override
	public Boolean deleteSubnets(JSONObject subnet) {
		JSONParser parser = new JSONParser();
		try {     
        	org.json.simple.JSONArray ar = (org.json.simple.JSONArray) parser.parse(new FileReader("Subnets.json"));
        	for (int i = 0; i < ar.size(); i++) {
        		Object o = ar.get(i);
        	    JSONObject policy1 = (JSONObject) o;  
        	    if(policy1.get("id").toString().equals(subnet.get("id").toString())){
            	    ar.remove(i);
            	    FileWriter file = new FileWriter("Subnets.json");
    		    	file.write(ar.toString());
    	    	    file.flush();
    	    	    file.close();
    	    	    return true;
        	    }
        	}
    	} catch (Exception e) {
        	System.out.println("deleteSubnets() : "+e);
        }
		return false;
	}
	
	@Override
	public void clearAllFiles() throws IOException {
		FileWriter file;
		file = new FileWriter("test.json");
    	file.write("");
    	file.flush();
	    file.close();
    	
    	FileWriter file1;
		file1 = new FileWriter("SubnetConfig.json");
    	file1.write("");
    	file1.flush();
	    file1.close();
    	
    	FileWriter file2;
		file2 = new FileWriter("Subnets.json");
    	file2.write("");
    	file2.flush();
	    file2.close();
	    
	    FileWriter file3;
		file3 = new FileWriter("layout.json");
    	file3.write("");
    	file3.flush();
	    file3.close();
	    
	    FileWriter file4;
		file4 = new FileWriter("tenants.json");
    	file4.write("");
    	file4.flush();
	    file4.close();
    	
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Object getLayout() {
		Map<String, List> map = new HashMap<String, List>();
		List<Object> li = new ArrayList<Object>();
		JSONParser parser = new JSONParser();
		Object o = null;
		try {     
        	JSONArray a = (JSONArray) parser.parse(new FileReader("layout.json"));
        	for (int i = 0; i < a.size(); i++) {
        		 o = a.get(i);
        		li.add(o);
        	  }
        } catch (Exception e) {
        	System.out.println("getLayout() : "+e);
        }
		map.put("topoLayout", li);
		return o;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Layout createLayout(Layout layout) throws Exception {
		JSONParser parser = new JSONParser();
		org.json.JSONObject jsonObject = null;
		
		 try { 
		    	ObjectMapper mapper = new ObjectMapper();
		    	String jsonInString = mapper.writeValueAsString(layout);
				jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(layout);
				jsonObject = new org.json.JSONObject(jsonInString);

				JSONArray ar = (JSONArray) parser.parse(new FileReader("layout.json"));
				ar.clear();
				ar.add(jsonObject);
				FileWriter file = new FileWriter("layout.json");
		    	file.write(ar.toJSONString());
	    	    file.flush();
	    	    file.close();
	    	    return layout;	    	    
	    } catch (Exception e) {
	    	JSONArray ar = new JSONArray();
	    	ar.clear();
			ar.add(jsonObject);
			FileWriter file;
			file = new FileWriter("layout.json");
	    	file.write(ar.toJSONString());
    	    file.flush();
    	    file.close();
	    	System.out.println("createLayout() : "+e);
	    	return layout;
	    }
	}

	@SuppressWarnings("unchecked")
	@Override
	public Tenant createTenants(Tenant tenant) throws Exception {
		System.out.println(tenant.tenantName);
		JSONParser parser = new JSONParser();
		org.json.JSONObject jsonObject = null;
		 try { 
			 if(tenant.id == null){
					Thread.sleep(1000);
					tenant.id = new SimpleDateFormat("dd HH:mm:ss").format(Calendar.getInstance().getTime()).replaceAll("[^a-zA-Z0-9]", "").toString();
				 }
		    	ObjectMapper mapper = new ObjectMapper();
		    	String jsonInString = mapper.writeValueAsString(tenant);
				jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(tenant);
				jsonObject = new org.json.JSONObject(jsonInString);

				JSONArray ar = (JSONArray) parser.parse(new FileReader("tenants.json"));
				
				ar.add(jsonObject);
				FileWriter file = new FileWriter("tenants.json");
		    	file.write(ar.toJSONString());
	    	    file.flush();
	    	    file.close();
	    	    return tenant;	    	    
	    } catch (Exception e) {
	    	JSONArray ar = new JSONArray();
	    	
			ar.add(jsonObject);
			FileWriter file;
			file = new FileWriter("tenants.json");
	    	file.write(ar.toJSONString());
    	    file.flush();
    	    file.close();
	    	System.out.println("createTenants() : "+e);
	    	return tenant;
	    }
	}

	@Override
	public Object getTenant(String tenant) throws Exception {
		JSONParser parser = new JSONParser();
		try {     
        	org.json.simple.JSONArray ar = (org.json.simple.JSONArray) parser.parse(new FileReader("tenants.json"));
        	for (int i = 0; i < ar.size(); i++) {
        		Object o = ar.get(i);
        		JSONObject t1 = (JSONObject) o;  
        	    if(t1.get("id").toString().equals(tenant)){
        	    	Object t = ar.get(i);
    	    	    return t;
        	    }
        	}
    	} catch (Exception e) {
        	System.out.println("getTenant() : "+e);
        }
		return null;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public Map<String, List> getTenants() {
		Map<String, List> map = new HashMap<String, List>();
		List<Object> li = new ArrayList<Object>();
		JSONParser parser = new JSONParser();
		try {     
        	JSONArray a = (JSONArray) parser.parse(new FileReader("tenants.json"));
        	for (int i = 0; i < a.size(); i++) {
        		Object o = a.get(i);
        		li.add(o);
        	  }
        } catch (Exception e) {
        	System.out.println("getTenants() : "+e);
        }
		map.put("tenants", li);
		return map;		
	}

	@SuppressWarnings("unchecked")
	@Override
	public Tenant updateTenants(Tenant tenant) {
		JSONParser parser = new JSONParser();
		org.json.JSONObject jsonObject = null;
		try {     
        	org.json.simple.JSONArray ar = (org.json.simple.JSONArray) parser.parse(new FileReader("tenants.json"));
        	for (int i = 0; i < ar.size(); i++) {
        		Object o = ar.get(i);
        	    JSONObject policy1 = (JSONObject) o;  
        	    if(policy1.get("id").toString().equals(tenant.id)){
            	    ar.remove(i);
            	    ObjectMapper mapper = new ObjectMapper();
    		    	String jsonInString = mapper.writeValueAsString(tenant);
    				jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(tenant);
    				jsonObject = new org.json.JSONObject(jsonInString);   
    				ar.add(jsonObject);    				
    				FileWriter file = new FileWriter("tenants.json");
    		    	file.write(ar.toString());
    	    	    file.flush();
    	    	    file.close();
    	    	    return tenant;
        	    }
        	}
    	} catch (Exception e) {
        	System.out.println("updateTenants() : "+e);
        }
		return null;	
	
		
	}	
}
