package com.cisco.segment.templateEngineservice.model;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;

@Component
public class Subnets {
	@JsonProperty
	public String nodeId;
	@JsonProperty
	public String displayName;
	@JsonProperty
	public String subnet;
	@JsonProperty
	public String id;
}
