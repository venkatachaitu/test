package com.cisco.segment;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import org.springframework.stereotype.Component;

import com.cisco.dcbu.lib.sshexec.impl.SshTransport;
import com.cisco.segment.templateEngineservice.model.Interfaces;
import com.cisco.segment.templateEngineservice.model.TemplateCLI;
import com.cisco.segment.templateEngineservice.model.TenantTemplate;

@Component
public class POAPTemplate {

	
	public void prepareCliCommands(TemplateCLI template) throws Exception{
		ArrayList<String> cmds = new ArrayList<String>();
		cmds.clear();
		cmds.add("conf t");
		cmds.add("mpls static configuration");
		cmds.add("address-family ipv4 unicast");
		if(template.pushMode.equalsIgnoreCase("true")){			
			cmds.add("lsp "+template.policy+"-"+template.inLabel);
			cmds.add("in-label "+template.inLabel+" allocate policy  "+template.subnet);
			cmds.add("forward");
			cmds.add("path 1 next-hop "+template.nextHop+" out-label-stack "+ template.connectingHops);		
		}else{
			cmds.add("no lsp "+template.policy+"-"+template.inLabel);
		}
		cmds.add("exit");		 
		executeCLI(template.sourceSwitchIP, cmds.toArray(new String[0]));		
	}
	
	@SuppressWarnings({ "rawtypes" })
	public void prepareCliCommands1(TenantTemplate template) throws Exception {
		ArrayList<String> cmds = new ArrayList<String>();
		cmds.clear();
		cmds.add("conf t");
		if(template.pushMode.equalsIgnoreCase("true")){
			cmds.add("vrf context "+template.vrf);
			cmds.add("rd auto");
			cmds.add("address-family ipv4 unicast");
			cmds.add("route-target import "+template.vpnId);
			cmds.add("route-target import "+template.vpnId+" evpn");
			cmds.add("route-target export "+template.vpnId);
			cmds.add("route-target export "+template.vpnId+" evpn");
			
			cmds.add("router bgp 10");
			cmds.add("vrf "+template.vrf);
			cmds.add("address-family ipv4 unicast");
			cmds.add("advertise l2vpn evpn");
			cmds.add("redistribute direct route-map PERMIT_ALL");
			
			List<Interfaces> li = template.interfaces;
			for (Iterator iterator = li.iterator(); iterator.hasNext();) {
				Interfaces interface1 = (Interfaces) iterator.next();
				
				cmds.add("interface "+interface1.ifName);
				cmds.add("vrf member "+template.vrf);
				cmds.add("no switchport");
				cmds.add("ip address "+interface1.ipAddress);
			}
			
		}else{
			List<Interfaces> li = template.nointerfaces;
			for (Iterator iterator = li.iterator(); iterator.hasNext();) {
				Interfaces interface1 = (Interfaces) iterator.next();
				
				cmds.add("interface "+interface1.ifName);
				cmds.add("no vrf member "+template.vrf);
			}
			
			if(template.vrfContext.equalsIgnoreCase("true")){
				cmds.add("no vrf context "+template.vrf);
			}
		}
		
		cmds.add("exit");
		executeCLI(template.sourceIP, cmds.toArray(new String[0]));		
	}
	
	public synchronized static void executeCLI(String switchIP, String [] cmdList) throws Exception{
		SshTransport sshTransp = null;
		try {
			sshTransp = new SshTransport();
        	sshTransp.openShell(switchIP, "admin", "cisco123");
			System.out.println("switch ip: "+switchIP);
        	for(int i=0; i<cmdList.length; i++){
				if(cmdList[i] != null){
					System.out.println(Thread.currentThread().getName()+" - Now sending out sshTransp.send for :"+cmdList[i] );
					try {	
						String response = sshTransp.send(cmdList[i]);
						Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
						long time = cal.getTimeInMillis();
						System.out.println(time+" : The response is:"+response);						 
					}catch(Exception ex1){
						throw new Exception(ex1.getMessage()+" While trying to deploy:"+cmdList[i]);
					}
				}
			}
		}catch (Exception e){
			System.out.println("executeCLI() : "+e);
		}finally {
			if(sshTransp != null)
				sshTransp.close();
		}
	}
}
