package com.cisco.segment.templateEngineservice.model;

import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;

@Component
public class Tenant {
	@JsonProperty
	public String id;
	@JsonProperty
	public String tenantName;
	@JsonProperty
	public String vpnId;
	@JsonProperty
	public Boolean isDeployed;
	@JsonProperty
	public List<TenantTemplate> configData;
}