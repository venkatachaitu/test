package com.cisco.segment.templateEngineservice.utils;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import com.cisco.segment.templateEngineservice.model.Layout;
import com.cisco.segment.templateEngineservice.model.ResponceCustom;
import com.cisco.segment.templateEngineservice.model.SubnetConfig;
import com.cisco.segment.templateEngineservice.model.Subnets;
import com.cisco.segment.templateEngineservice.model.Tenant;
@Service
public interface JsonFileHandler {
	public ResponceCustom addPolicy(ResponceCustom policy) throws Exception;
	@SuppressWarnings("rawtypes")
	public Map<String, List> getPolicies();
	public ResponceCustom updatePolicy(ResponceCustom policy);
	public boolean deletePolicy(ResponceCustom policy);
	public SubnetConfig createVrfService(SubnetConfig policy) throws Exception;
	@SuppressWarnings("rawtypes")
	public Map<String, List> getVrfService();
	public Subnets createSubnet(Subnets subnet) throws Exception;
	@SuppressWarnings("rawtypes")
	public Map<String, List> getSubnets();
	public void clearAllFiles() throws IOException;
	public Subnets updateSubnets(Subnets subnet);
	public Boolean deleteSubnets(JSONObject subnet);
	public Object getLayout();
	public Layout createLayout(Layout layout) throws Exception ;
	public SubnetConfig updateVrfService(SubnetConfig policy);
	public Tenant createTenants(Tenant tenant) throws Exception;
	public Object getTenant(String tenant) throws Exception;
	@SuppressWarnings("rawtypes")
	public Map<String, List> getTenants();
	public Tenant updateTenants(Tenant tenant);
}
