package com.cisco.segment.templateEngineservice.model;

import java.util.List;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;

@Component
public class TenantTemplate {
	@JsonProperty
	public String sourceIP;
	@JsonProperty
	public String vrf;
	@JsonProperty
	public String vpnId;
	@JsonProperty
	public String switchId;
	@JsonProperty
	public String displayName;
	@JsonProperty
	public List<Interfaces> interfaces;
	@JsonProperty
	public List<Interfaces> nointerfaces;
	@JsonProperty
	public String pushMode;
	@JsonProperty
	public String vrfContext;
}
