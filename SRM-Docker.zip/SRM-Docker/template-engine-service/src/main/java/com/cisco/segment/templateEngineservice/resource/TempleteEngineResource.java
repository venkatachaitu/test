package com.cisco.segment.templateEngineservice.resource;

import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cisco.segment.POAPTemplate;
import com.cisco.segment.templateEngineservice.model.Layout;
import com.cisco.segment.templateEngineservice.model.ResponceCustom;
import com.cisco.segment.templateEngineservice.model.SubnetConfig;
import com.cisco.segment.templateEngineservice.model.Subnets;
import com.cisco.segment.templateEngineservice.model.TemplateCLI;
import com.cisco.segment.templateEngineservice.model.Tenant;
import com.cisco.segment.templateEngineservice.model.TenantTemplate;
import com.cisco.segment.templateEngineservice.utils.JsonFileHandler;

@RestController
@RequestMapping("/")
public class TempleteEngineResource {
	
	@Autowired
	POAPTemplate pOAPTemplate;
	@Autowired
	RestTemplate restTemplate;

	@Autowired
	JsonFileHandler jsonFileHandler;

	@GetMapping("/tetest")
	public String test(){
		System.out.println("-------------------------------------------------------------------------entered template engine-------------------------------------------------------------------------");
		return "message from template engine...";
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(path="/policies", method= RequestMethod.POST)
	public ResponseEntity<Object> createPolicy(@RequestBody ResponceCustom policy) throws Exception{
		HttpHeaders response = new HttpHeaders();
	    response.set("Access-Control-Allow-Origin", "*");
	       
	    ResponceCustom r = jsonFileHandler.addPolicy(policy);
	    if(r != null)
	    	return new ResponseEntity<Object>(r, response, HttpStatus.OK);
	    else
	    	return new ResponseEntity<Object>("already existed..!", response, HttpStatus.NOT_ACCEPTABLE); 
	}	
	
	@SuppressWarnings("rawtypes")
	@RequestMapping(path="/policies", method= RequestMethod.GET)
	public ResponseEntity<Map<String, List>> getPolicies() throws Exception{
		HttpHeaders response = new HttpHeaders();
	    response.set("Access-Control-Allow-Origin", "*");
	    Map<String, List> list = jsonFileHandler.getPolicies();	    
	    return new ResponseEntity<Map<String, List>>(list, response, HttpStatus.OK); 
	}
	
	@RequestMapping(path="/policies", method= RequestMethod.PUT)
	public ResponseEntity<Object> updatePolicy(@RequestBody ResponceCustom policy) throws Exception{
		HttpHeaders response = new HttpHeaders();
	    response.set("Access-Control-Allow-Origin", "*");
	    ResponceCustom r = jsonFileHandler.updatePolicy(policy);	    
	    if(r != null)
	    	return new ResponseEntity<Object>(r, response, HttpStatus.OK);
	    else
	    	return new ResponseEntity<Object>("policy not found.", response, HttpStatus.NOT_FOUND);
	}
	
	@RequestMapping(path="/policies", method= RequestMethod.DELETE)
	public ResponseEntity<Object> deletePolicy(@RequestBody ResponceCustom policy) throws Exception{
		HttpHeaders response = new HttpHeaders();
	    response.set("Access-Control-Allow-Origin", "*");
	    Boolean r = jsonFileHandler.deletePolicy(policy);	    
	    if(r)
	    	return new ResponseEntity<Object>("deleted", response, HttpStatus.OK);
	    else
	    	return new ResponseEntity<Object>("policy not found.", response, HttpStatus.NOT_FOUND);
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(path="/config", method= RequestMethod.POST)
	public ResponseEntity<Object> createVrfService(@RequestBody SubnetConfig policy) throws Exception{
		HttpHeaders response = new HttpHeaders();
	    response.set("Access-Control-Allow-Origin", "*");
	       
	    SubnetConfig r = jsonFileHandler.createVrfService(policy);
	    if(r != null)
	    	return new ResponseEntity<Object>(r, response, HttpStatus.OK);
	    else
	    	return new ResponseEntity<Object>("already existed..!", response, HttpStatus.NOT_ACCEPTABLE); 
	}
	
	@SuppressWarnings("rawtypes")
	@RequestMapping(path="/config", method= RequestMethod.GET)
	public ResponseEntity<Map<String, List>> getVrfService() throws Exception{
		HttpHeaders response = new HttpHeaders();
	    response.set("Access-Control-Allow-Origin", "*");
	    Map<String, List> list = jsonFileHandler.getVrfService();
	    
	    return new ResponseEntity<Map<String, List>>(list, response, HttpStatus.OK); 
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(path="/config", method= RequestMethod.PUT)
	public ResponseEntity<Object> updateVrfService(@RequestBody SubnetConfig policy) throws Exception{
		HttpHeaders response = new HttpHeaders();
	    response.set("Access-Control-Allow-Origin", "*");
	    SubnetConfig r = jsonFileHandler.updateVrfService(policy);	    
	    if(r != null)
	    	return new ResponseEntity<Object>(r, response, HttpStatus.OK);
	    else
	    	return new ResponseEntity<Object>("Not found.", response, HttpStatus.NOT_FOUND);
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(path="/subnets", method= RequestMethod.POST)
	public ResponseEntity<Object> createSubnet(@RequestBody Subnets subnet) throws Exception{
		HttpHeaders response = new HttpHeaders();
	    response.set("Access-Control-Allow-Origin", "*");
	       
	    Subnets r = jsonFileHandler.createSubnet(subnet);
	    if(r != null)
	    	return new ResponseEntity<Object>(r, response, HttpStatus.OK);
	    else
	    	return new ResponseEntity<Object>("already existed..!", response, HttpStatus.NOT_ACCEPTABLE); 
	}
	
	@CrossOrigin(origins = "*")
	@SuppressWarnings("rawtypes")
	@RequestMapping(path="/subnets", method= RequestMethod.GET)
	public ResponseEntity<Map<String, List>> getSubnets() throws Exception{
		HttpHeaders response = new HttpHeaders();
	    response.set("Access-Control-Allow-Origin", "*");
	    Map<String, List> list = jsonFileHandler.getSubnets();	    
	    return new ResponseEntity<Map<String, List>>(list, response, HttpStatus.OK); 
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(path="/subnets", method= RequestMethod.PUT)
	public ResponseEntity<Object> updateSubnets(@RequestBody Subnets subnet) throws Exception{
		HttpHeaders response = new HttpHeaders();
	    response.set("Access-Control-Allow-Origin", "*");
	    Subnets r = jsonFileHandler.updateSubnets(subnet);	    
	    if(r != null)
	    	return new ResponseEntity<Object>(r, response, HttpStatus.OK);
	    else
	    	return new ResponseEntity<Object>("subnet not found.", response, HttpStatus.NOT_FOUND);
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(path="/subnets", method= RequestMethod.DELETE)
	public ResponseEntity<Object> deleteSubnets(@RequestBody JSONObject subnet) throws Exception{
		HttpHeaders response = new HttpHeaders();
	    response.set("Access-Control-Allow-Origin", "*");
	    Boolean r = jsonFileHandler.deleteSubnets(subnet);	    
	    if(r)
	    	return new ResponseEntity<Object>("subnet deleted", response, HttpStatus.OK);
	    else
	    	return new ResponseEntity<Object>("subnet not found.", response, HttpStatus.NOT_FOUND);
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(path="/pushconfig", method= RequestMethod.POST)
	public ResponseEntity<String> prepareCliCommands(@RequestBody TemplateCLI template) throws Exception{	
		pOAPTemplate.prepareCliCommands(template);		
		HttpHeaders responseHeaders = new HttpHeaders();
	    responseHeaders.set("Access-Control-Allow-Origin", "*");
		return new ResponseEntity<String>(responseHeaders, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(path="/pushtenantconfig", method= RequestMethod.POST)
	public ResponseEntity<String> prepareCliCommands1(@RequestBody TenantTemplate template) throws Exception{
		Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
		long time = cal.getTimeInMillis();
		
		System.out.println("Request for pushtenantconfig: "+time);
		pOAPTemplate.prepareCliCommands1(template);		
		HttpHeaders responseHeaders = new HttpHeaders();
	    responseHeaders.set("Access-Control-Allow-Origin", "*");
		return new ResponseEntity<String>(responseHeaders, HttpStatus.OK);
	}

	/* api for clear all the files*/
	@SuppressWarnings({ "rawtypes" })
	@RequestMapping(path="/clear", method= RequestMethod.GET)
	public ResponseEntity clearAll() throws Exception{
	    jsonFileHandler.clearAllFiles();	    
	    return new ResponseEntity(HttpStatus.OK); 
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(path="/layout", method= RequestMethod.POST)
	public ResponseEntity<Object> createLayout(@RequestBody Layout layout) throws Exception{
		HttpHeaders response = new HttpHeaders();
	    response.set("Access-Control-Allow-Origin", "*");
	       
	    Layout r = jsonFileHandler.createLayout(layout);
	    if(r != null)
	    	return new ResponseEntity<Object>(r, response, HttpStatus.OK);
	    else
	    	return new ResponseEntity<Object>("already existed..!", response, HttpStatus.NOT_ACCEPTABLE); 
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(path="/layout", method= RequestMethod.GET)
	public ResponseEntity<Object> getLayout() throws Exception{
		HttpHeaders response = new HttpHeaders();
	    response.set("Access-Control-Allow-Origin", "*");
	    Object list = jsonFileHandler.getLayout();	    
	    return new ResponseEntity<Object>(list, response, HttpStatus.OK); 
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(path="/tenants", method= RequestMethod.POST)
	public ResponseEntity<Object> createTenants(@RequestBody Tenant tenant) throws Exception{
		HttpHeaders response = new HttpHeaders();
	    response.set("Access-Control-Allow-Origin", "*");
	    Tenant r = jsonFileHandler.createTenants(tenant);
	    if(r != null)
	    	return new ResponseEntity<Object>(r, response, HttpStatus.OK);
	    else
	    	return new ResponseEntity<Object>("already existed..!", response, HttpStatus.NOT_ACCEPTABLE); 
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(path="/tenants", method= RequestMethod.PUT)
	public ResponseEntity<Object> updateTenants(@RequestBody Tenant tenant) throws Exception{
		HttpHeaders response = new HttpHeaders();
	    response.set("Access-Control-Allow-Origin", "*");
	    Tenant r = jsonFileHandler.updateTenants(tenant);
	    if(r != null)
	    	return new ResponseEntity<Object>(r, response, HttpStatus.OK);
	    else
	    	return new ResponseEntity<Object>("already existed..!", response, HttpStatus.NOT_ACCEPTABLE); 
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(path="/tenants/{tenant}", method= RequestMethod.GET)
	public ResponseEntity<Object> getTenantById(@PathVariable String tenant) throws Exception{
		HttpHeaders response = new HttpHeaders();
	    response.set("Access-Control-Allow-Origin", "*");
	    Object r = null;
		if(tenant != "" || tenant != null){			
		    r = jsonFileHandler.getTenant(tenant);	    		    
		}
		if(r != null)
			return new ResponseEntity<Object>(r, HttpStatus.OK);
		else
			return new ResponseEntity<Object>(HttpStatus.NOT_FOUND);
	}
	
	@SuppressWarnings("rawtypes")
	@CrossOrigin(origins = "*")
	@RequestMapping(path="/tenants", method= RequestMethod.GET)
	public ResponseEntity<Map<String, List>> getTenants() throws Exception{
		HttpHeaders response = new HttpHeaders();
	    response.set("Access-Control-Allow-Origin", "*");
	    Map<String, List> list = jsonFileHandler.getTenants();	    
	    return new ResponseEntity<Map<String, List>>(list, response, HttpStatus.OK); 
	}
}
