package com.cisco.segment.templateEngineservice.model;

import java.util.ArrayList;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;

@Component
public class ResponceCustom {
	@JsonProperty
	public String POLICY_NAME;
	@JsonProperty
	public String PREFIX_SR;
	@JsonProperty
	public String startingNode;
	@JsonProperty
	public String destinationNode;
	@JsonProperty
	public ArrayList<RouteNodes> routes;
	@JsonProperty
	public String srcDisplayName;
	@JsonProperty
	public String destDisplayName;
}

