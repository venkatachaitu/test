package com.cisco.segment.templateEngineservice.model;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;

@Component
public class RouteNodes {
	@JsonProperty
	public String startingNode;
	@JsonProperty
	public String destinationNode;
	@JsonProperty
	public String interfaceId;
	
}
