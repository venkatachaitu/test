package com.cisco.segment.templateEngineservice.model;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;

@Component
public class SubnetConfig {
	@JsonProperty
	public String policy;
	@JsonProperty
	public String subnet;
	@JsonProperty
	public String destId;
	@JsonProperty
	public String sourceId;
	@JsonProperty
	public String srcDisplayName;
	@JsonProperty
	public String destDisplayName;
	@JsonProperty
	public String inLabel;
	@JsonProperty
	public Boolean isDeployed;
	@JsonProperty
	public String id;
	
}
